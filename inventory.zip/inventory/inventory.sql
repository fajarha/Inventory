-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 14, 2020 at 05:23 PM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `inventory`
--

-- --------------------------------------------------------

--
-- Table structure for table `approval`
--

CREATE TABLE `approval` (
  `id_approval` int(11) NOT NULL,
  `nik_pembeli` varchar(16) DEFAULT NULL,
  `nama_pembeli` varchar(20) NOT NULL,
  `harga_pembelian` int(11) NOT NULL,
  `kd_barang` varchar(15) NOT NULL,
  `tanggal_pembelian` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `barang`
--

CREATE TABLE `barang` (
  `kd_barang` varchar(15) NOT NULL,
  `nik` varchar(16) DEFAULT NULL,
  `nama_customer` varchar(30) NOT NULL,
  `no_aggrement` varchar(14) NOT NULL,
  `ovd` varchar(11) NOT NULL,
  `status_konsumen` enum('Normal','Wo','Release') NOT NULL,
  `kategori` enum('KMB','KMOB','WG') NOT NULL,
  `merk` varchar(30) NOT NULL,
  `no_rangka` varchar(20) DEFAULT NULL,
  `no_serial` varchar(20) DEFAULT NULL,
  `no_mesin` varchar(20) DEFAULT NULL,
  `warna` varchar(12) NOT NULL,
  `no_polisi` varchar(10) DEFAULT NULL,
  `status_barang` enum('Reposes','Inventory','Sold','Release') NOT NULL,
  `otr` int(11) NOT NULL,
  `nilai_barang` int(11) NOT NULL,
  `nilai_denda` int(11) NOT NULL,
  `sisa_denda` int(11) NOT NULL,
  `biaya_tarik` int(11) NOT NULL,
  `umur_barang` date NOT NULL,
  `nik_collector` int(11) NOT NULL,
  `nama_collector` varchar(20) NOT NULL,
  `lokasi` varchar(20) NOT NULL,
  `tanggal_stnk` date DEFAULT NULL,
  `tanggal_pajak` date DEFAULT NULL,
  `deskripsi_barang` varchar(80) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `barang`
--

INSERT INTO `barang` (`kd_barang`, `nik`, `nama_customer`, `no_aggrement`, `ovd`, `status_konsumen`, `kategori`, `merk`, `no_rangka`, `no_serial`, `no_mesin`, `warna`, `no_polisi`, `status_barang`, `otr`, `nilai_barang`, `nilai_denda`, `sisa_denda`, `biaya_tarik`, `umur_barang`, `nik_collector`, `nama_collector`, `lokasi`, `tanggal_stnk`, `tanggal_pajak`, `deskripsi_barang`) VALUES
('BRG04052020001', '3671012412970007', 'Fajar Hafidzi', '04011019014216', '40', 'Normal', 'KMB', 'YAMAHA', 'MH31KP00BDJ657609', '', '1KP657345', 'BIRU', 'B 3456 CLD', 'Inventory', 12000000, 7000000, 1500000, 300000, 200000, '2020-05-04', 67046, 'Fajar', 'Tangerang', '2020-05-19', '2020-05-17', 'Barang Cukup Baik'),
('BRG04052020002', '3671012412970007', 'Fajar Hafidzi', '04011019003458', '-', 'Wo', 'KMB', 'YAMAHA', 'MH31KP00BDJ657609', '', '1KP657345', 'BIRU', 'B 7680 CLD', 'Release', 12000000, 7000000, 1500000, 300000, 200000, '2020-05-04', 67046, 'Fajar', 'Tangerang', '2020-05-20', '2020-05-28', 'Barang cukup baik'),
('BRG04052020003', '', 'Fajar Hafidzi', '04011018014214', '40', 'Normal', 'KMB', 'YAMAHA', 'MH31KP00BDJ657609', '', '1KP657345', 'BIRU', 'B 3455 CLD', 'Sold', 12000000, 7000000, 1500000, 300000, 200000, '2020-05-04', 67046, 'Fajar', 'Tangerang', '2020-05-13', '2020-05-31', 'Barang cukup baik');

-- --------------------------------------------------------

--
-- Table structure for table `barang_terjual`
--

CREATE TABLE `barang_terjual` (
  `invoice` varchar(15) NOT NULL,
  `kd_barang` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `barang_terjual`
--

INSERT INTO `barang_terjual` (`invoice`, `kd_barang`) VALUES
('PJL07052020003', 'BRG04052020002'),
('PJL07052020004', 'BRG04052020002'),
('PJL07052020005', 'BRG04052020002'),
('PJL07052020006', 'BRG04052020003');

-- --------------------------------------------------------

--
-- Table structure for table `bayar_detail`
--

CREATE TABLE `bayar_detail` (
  `no_kwitansi` varchar(15) NOT NULL,
  `kd_barang` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bayar_detail`
--

INSERT INTO `bayar_detail` (`no_kwitansi`, `kd_barang`) VALUES
('BRG10062020004', 'BRG04052020002'),
('BRG11062020004', 'BRG04052020002'),
('INV11062020005', 'BRG04052020002'),
('INV11062020006', 'BRG04052020002'),
('INV11062020007', 'BRG04052020002'),
('INV11062020008', 'BRG04052020002'),
('INV11062020009', 'BRG04052020002'),
('INV11062020010', 'BRG04052020002'),
('INV11062020011', 'BRG04052020002'),
('INV11062020012', 'BRG04052020002'),
('INV11062020013', 'BRG04052020002'),
('INV11062020014', 'BRG04052020002'),
('INV11062020015', 'BRG04052020002'),
('INV11062020016', 'BRG04052020002'),
('INV11062020017', 'BRG04052020002'),
('INV11062020018', 'BRG04052020002'),
('INV11062020019', 'BRG04052020002'),
('INV11062020020', 'BRG04052020002'),
('INV11062020021', 'BRG04052020002'),
('INV11062020022', 'BRG04052020002'),
('INV11062020023', 'BRG04052020002'),
('INV11062020024', 'BRG04052020002'),
('INV11062020025', 'BRG04052020002');

-- --------------------------------------------------------

--
-- Table structure for table `pembayaran`
--

CREATE TABLE `pembayaran` (
  `no_kwitansi` varchar(15) NOT NULL,
  `kd_barang` varchar(15) NOT NULL,
  `invoice` varchar(15) NOT NULL,
  `jumlah_pembayaran` int(11) NOT NULL,
  `tanggal_pembayaran` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pembayaran`
--

INSERT INTO `pembayaran` (`no_kwitansi`, `kd_barang`, `invoice`, `jumlah_pembayaran`, `tanggal_pembayaran`) VALUES
('BRG10062020004', 'BRG04052020002', 'PJL07052020001', 6500000, '2020-06-10'),
('BRG11062020004', 'BRG04052020002', 'PJL07052020002', 6500000, '2020-06-11'),
('INV11062020005', 'BRG04052020002', 'PJL07052020003', 6500000, '2020-06-11'),
('INV11062020006', 'BRG04052020002', 'PJL07052020004', 6500000, '2020-06-11'),
('INV11062020007', 'BRG04052020002', 'PJL07052020005', 6500000, '2020-06-11'),
('INV11062020008', 'BRG04052020002', 'PJL07052020002', 6500000, '2020-06-11'),
('INV11062020009', 'BRG04052020002', 'PJL07052020002', 6500000, '2020-06-11'),
('INV11062020010', 'BRG04052020002', 'PJL07052020001', 6500000, '2020-06-11'),
('INV11062020011', 'BRG04052020002', 'PJL07052020001', 6500000, '2020-06-11'),
('INV11062020012', 'BRG04052020002', 'PJL07052020001', 6500000, '2020-06-11'),
('INV11062020013', 'BRG04052020002', 'PJL07052020001', 6500000, '2020-06-11'),
('INV11062020014', 'BRG04052020002', 'PJL07052020001', 6500000, '2020-06-11'),
('INV11062020015', 'BRG04052020002', 'PJL07052020001', 6500000, '2020-06-11'),
('INV11062020016', 'BRG04052020002', 'PJL07052020001', 6500000, '2020-06-11'),
('INV11062020017', 'BRG04052020002', 'PJL07052020001', 6500000, '2020-06-11'),
('INV11062020018', 'BRG04052020002', 'PJL07052020001', 6500000, '2020-06-11'),
('INV11062020019', 'BRG04052020002', 'PJL07052020001', 6500000, '2020-06-11'),
('INV11062020020', 'BRG04052020002', 'PJL07052020001', 6500000, '2020-06-11'),
('INV11062020021', 'BRG04052020002', 'PJL07052020001', 6500000, '2020-06-11'),
('INV11062020022', 'BRG04052020002', 'PJL07052020001', 6500000, '2020-06-11'),
('INV11062020023', 'BRG04052020002', 'PJL07052020001', 6500000, '2020-06-11'),
('INV11062020024', 'BRG04052020002', 'PJL07052020001', 6500000, '2020-06-11'),
('INV11062020025', 'BRG04052020002', 'PJL07052020001', 6500000, '2020-06-11');

-- --------------------------------------------------------

--
-- Table structure for table `pending`
--

CREATE TABLE `pending` (
  `id_pending` int(11) NOT NULL,
  `nik_pembeli` varchar(16) DEFAULT NULL,
  `kd_barang` varchar(15) NOT NULL,
  `nama_pembeli` varchar(20) NOT NULL,
  `harga_pembelian` int(11) NOT NULL,
  `tanggal_pembelian` date NOT NULL,
  `keterangan` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `penjualan_barang`
--

CREATE TABLE `penjualan_barang` (
  `invoice` varchar(15) NOT NULL,
  `nama_pembeli` varchar(30) NOT NULL,
  `nik_pembeli` varchar(16) DEFAULT NULL,
  `kd_barang` varchar(15) NOT NULL,
  `harga_pembelian` int(11) NOT NULL,
  `tanggal_pembelian` date NOT NULL,
  `status` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `penjualan_barang`
--

INSERT INTO `penjualan_barang` (`invoice`, `nama_pembeli`, `nik_pembeli`, `kd_barang`, `harga_pembelian`, `tanggal_pembelian`, `status`) VALUES
('PJL07052020001', 'WANTO', '3671012412970006', 'BRG04052020002', 6500000, '2020-05-06', 'Lunas'),
('PJL07052020002', 'WANTO', '3671012412970006', 'BRG04052020002', 6500000, '2020-05-06', 'Lunas'),
('PJL07052020003', 'WANTO', '3671012412970006', 'BRG04052020002', 6500000, '2020-05-06', 'Lunas'),
('PJL07052020004', 'WANTO', '3671012412970006', 'BRG04052020002', 6500000, '2020-05-06', 'Lunas'),
('PJL07052020005', 'WANTO', '3671012412970006', 'BRG04052020002', 6500000, '2020-05-06', 'Lunas'),
('PJL07052020006', 'Agung', '3671012412970005', 'BRG04052020003', 5000000, '2020-05-07', 'Waiting');

-- --------------------------------------------------------

--
-- Table structure for table `role`
--

CREATE TABLE `role` (
  `id` int(11) NOT NULL,
  `role` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `role`
--

INSERT INTO `role` (`id`, `role`) VALUES
(1, 'Administrator'),
(2, 'Manager'),
(3, 'Admin'),
(4, 'Kasir');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `nik` int(11) NOT NULL,
  `nama_lengkap` varchar(30) NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `alamat` varchar(50) NOT NULL,
  `username` varchar(10) NOT NULL,
  `password` varchar(256) NOT NULL,
  `role_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`nik`, `nama_lengkap`, `tanggal_lahir`, `alamat`, `username`, `password`, `role_id`) VALUES
(60000, 'Manager', '2020-04-15', 'Kredit Plus', 'Manager', '696d29e0940a4957748fe3fc9efd22a3', 2),
(67046, 'Fajar Hafidzi', '1997-12-24', 'Budiasih', 'FajarH', '5f4dcc3b5aa765d61d8327deb882cf99', 1),
(67079, 'Inventory', '2020-04-01', 'Tangerang', 'Inventory', '5f4dcc3b5aa765d61d8327deb882cf99', 3),
(67080, 'Kasir', '2020-06-16', 'Tangerang', 'Kasir', '5f4dcc3b5aa765d61d8327deb882cf99', 4);

-- --------------------------------------------------------

--
-- Table structure for table `user_access_menu`
--

CREATE TABLE `user_access_menu` (
  `id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_access_menu`
--

INSERT INTO `user_access_menu` (`id`, `role_id`, `menu_id`) VALUES
(1, 1, 1),
(5, 1, 3),
(6, 1, 4),
(7, 1, 5),
(8, 1, 6),
(9, 1, 7),
(10, 1, 8),
(11, 2, 1),
(12, 2, 5),
(13, 2, 6),
(14, 2, 7),
(15, 2, 9),
(17, 3, 1),
(19, 3, 5),
(20, 3, 7),
(21, 3, 9),
(23, 1, 9),
(24, 4, 1),
(25, 4, 8),
(26, 4, 9),
(27, 2, 8);

-- --------------------------------------------------------

--
-- Table structure for table `user_menu`
--

CREATE TABLE `user_menu` (
  `id` int(11) NOT NULL,
  `menu` varchar(15) NOT NULL,
  `icon` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_menu`
--

INSERT INTO `user_menu` (`id`, `menu`, `icon`) VALUES
(1, 'Dashboard', 'fa fa-tachometer'),
(3, 'User Management', 'fa fa-user'),
(4, 'Menu Management', 'fa fa-folder'),
(5, 'Asset Managemen', 'fa fa-folder'),
(6, 'Approval', 'fa fa-edit'),
(7, 'Transaksi', 'fa fa-file-text'),
(8, 'Pembayaran', 'fa fa-cc-mastercard'),
(9, 'Laporan', 'fa fa-book');

-- --------------------------------------------------------

--
-- Table structure for table `user_sub_menu`
--

CREATE TABLE `user_sub_menu` (
  `id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL,
  `title` varchar(30) NOT NULL,
  `url` varchar(30) NOT NULL,
  `iconic` varchar(30) NOT NULL,
  `is_active` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_sub_menu`
--

INSERT INTO `user_sub_menu` (`id`, `menu_id`, `title`, `url`, `iconic`, `is_active`) VALUES
(4, 3, 'Create User', 'User/Create', 'fa fa-circle-o', 1),
(6, 3, 'Detail User', 'User', 'fa fa-circle-o', 1),
(7, 4, 'Sub Menu', 'Menu/SubMenu', 'fa fa-circle-o', 1),
(8, 4, 'Access Menu', 'Menu/Access', 'fa fa-circle-o', 1),
(9, 4, 'Menu', 'Menu', 'fa fa-circle-o', 1),
(10, 5, 'Asset Receive', 'Asset/Receive', 'fa fa-circle-o', 1),
(11, 5, 'Asset Terjual', 'Asset/Terjual', 'fa fa-circle-o', 1),
(13, 5, 'Stok Asset', 'Asset/Stok', 'fa fa-circle-o', 1),
(14, 6, 'Approval Penjualan', 'Transaksi/Approval', 'fa fa-circle-o', 1),
(17, 7, 'Penjualan', 'Transaksi/Penjualan', 'fa fa-circle-o', 1),
(18, 5, 'Asset Pending', 'Asset/Pending', 'fa fa-circle-o', 1),
(19, 8, 'Input', 'Pembayaran/input', 'fa fa-circle-o', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `approval`
--
ALTER TABLE `approval`
  ADD PRIMARY KEY (`id_approval`);

--
-- Indexes for table `barang`
--
ALTER TABLE `barang`
  ADD PRIMARY KEY (`kd_barang`);

--
-- Indexes for table `pembayaran`
--
ALTER TABLE `pembayaran`
  ADD PRIMARY KEY (`no_kwitansi`);

--
-- Indexes for table `pending`
--
ALTER TABLE `pending`
  ADD PRIMARY KEY (`id_pending`);

--
-- Indexes for table `penjualan_barang`
--
ALTER TABLE `penjualan_barang`
  ADD PRIMARY KEY (`invoice`);

--
-- Indexes for table `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`nik`);

--
-- Indexes for table `user_access_menu`
--
ALTER TABLE `user_access_menu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_menu`
--
ALTER TABLE `user_menu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_sub_menu`
--
ALTER TABLE `user_sub_menu`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `approval`
--
ALTER TABLE `approval`
  MODIFY `id_approval` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `pending`
--
ALTER TABLE `pending`
  MODIFY `id_pending` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `role`
--
ALTER TABLE `role`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `user_access_menu`
--
ALTER TABLE `user_access_menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `user_menu`
--
ALTER TABLE `user_menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `user_sub_menu`
--
ALTER TABLE `user_sub_menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
