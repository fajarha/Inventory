<div class="content-wrapper">
	<!--content header-->
	<div class="content-header">
		<div class="conteiner fluid">
			<div class="row mb-2">
				<div class="col-sm-6">
					<h1 class="m-0 text-dark"><?= $title; ?></h1>
				</div>
			</div>
		</div>
	</div>

	<!-- Main content -->
	<section class="content">
		<div class="row">
			<div class="col-lg-12">
				<div class="box">

					<div class="box-body">

						<div class="row pl-5">
							<form action="<?= base_url('User/Create'); ?>" method="post">
								<div class="modal-body">

									<?= $this->session->flashdata('pesan'); ?>
									<div class="form-group row">
										<div class="col-lg-2">
											<label for="nik">NIK</label>
											<input type="text" class="form-control" id="nik" name="nik" placeholder="Masukan Nik ">
											<?php echo form_error('nik'); ?>
										</div>

										<div class="col-lg-4">
											<label for="nama_lengkap">Nama Lengkap</label>
											<input type="text" class="form-control" id="nama_lengkap" name="nama_lengkap" placeholder="Masukan Nama Lengkap">
											<?php echo form_error('nama_lengkap'); ?>
										</div>
									</div>

									<div class="form-group row">
										<div class="col-lg-6">
											<label for="tgl">Tanggal Lahir</label>
											<input type="text" class="form-control" id="tgl" name="tanggal_lahir" placeholder="Masukan Tanggal Lahir">
											<?php echo form_error('tanggal_lahir'); ?>
										</div>
									</div>

									<div class="form-group row">
										<div class="col-lg-6">
											<label for="alamat">Alamat</label>
											<textarea class="form-control" id="alamat" name="alamat" placeholder="Masukan Alamat "></textarea>
											<?php echo form_error('alamat'); ?>
										</div>
									</div>

									<div class="form-group row">
										<div class="col-lg-6">
											<label for="username">Username</label>
											<input type="text" class="form-control" id="username" name="username" placeholder="Masukan Username">
											<?php echo form_error('username'); ?>
										</div>
									</div>

									<div class="form-group row">
										<div class="col-lg-6">
											<label for="passwword">Password</label>
											<input type="password" class="form-control" id="password" name="password" placeholder="Masukan Password">
											<?php echo form_error('password'); ?>
										</div>
									</div>


									<div class="form-group row">
										<div class="col-lg-6">
											<label for="role_id"> Role</label>
											<select name="role_id" id="role_id" class="form-control">
												<option value="">Select Role</option>
												<?php foreach ($role as $r) : ?>
													<option value="<?= $r['id']; ?>"><?= $r['role']; ?></option>
												<?php endforeach; ?>
											</select>
										</div>
									</div>
								</div>


								<div class="col-lg-6" align="right">
									<a href="<?= base_url('User'); ?>" class="btn btn-danger">Close</a>
									<button type="submit" class="btn btn-primary">Create</button>
								</div>

							</form>

						</div>
					</div>
				</div>


			</div>
		</div>
	</section>

</div>
