<div class="content-wrapper">
	<!--content header-->
	<div class="content-header">
		<div class="conteiner fluid">
			<div class="row mb-2">
				<div class="col-sm-6">
					<h1 class="m-0 text-dark"><?= $title; ?></h1>
				</div>
			</div>
		</div>
	</div>

	<!-- Main content -->
	<section class="content">
		<div class="row">
			<div class="col-lg-12">
				<div class="box">

					<div class="box-body">

						<div class="row pl-5">
							<form action="" method="post">
								<?= $this->session->flashdata('pesan'); ?>
								<div class="modal-body">

									<div class="form-group row">
										<div class="col-lg-2">
											<label for="nik">NIK</label>
											<input type="text" class="form-control" id="nik" name="nik" value="<?= $pengguna['nik']; ?>" readonly>
											<?php echo form_error('nik'); ?>
										</div>

										<div class="col-lg-4">
											<label for="nama_lengkap">Nama Lengkap</label>
											<input type="text" class="form-control" id="nama_lengkap" name="nama_lengkap" value="<?= $pengguna['nama_lengkap']; ?>"">
											<?php echo form_error('nama_lengkap'); ?>
										</div>
									</div>

									<div class=" form-group row">
											<div class="col-lg-6">
												<label for="tgl">Tanggal Lahir</label>
												<input type="text" class="form-control" id="tgl" name="tanggal_lahir" value="<?= $pengguna['tanggal_lahir']; ?>">
												<?php echo form_error('tanggal_lahir'); ?>
											</div>
										</div>

										<div class=" form-group row">
											<div class="col-lg-6">
												<label for="alamat">Alamat</label>
												<textarea class="form-control" id="alamat" name="alamat" value=""><?= $pengguna['alamat']; ?></textarea>
												<?php echo form_error('alamat'); ?>
											</div>
										</div>

										<div class=" form-group row">
											<div class="col-lg-6">
												<label for="username">Username</label>
												<input type="text" class="form-control" id="username" name="username" value="<?= $pengguna['username']; ?>">
												<?php echo form_error('username'); ?>
											</div>
										</div>

										<div class=" form-group row">
											<div class="col-lg-6">
												<label for="passwword">Password</label>
												<input type="password" class="form-control" id="password" name="password" value="<?= $pengguna['password']; ?>">
												<?php echo form_error('password'); ?>
											</div>
										</div>

										<div class="form-group row">
											<div class="col-lg-6">
												<select name="role_id" id="role_id" class="form-control">
													<option value="">Select Role</option>
													<?php foreach ($role as $r) : ?>
														<option value="<?= $r['id']; ?>"><?= $r['role']; ?></option>
													<?php endforeach; ?>
												</select>
												<?php echo form_error('role'); ?>
											</div>
										</div>

										<div class="col-lg-6" align="right">
											<a href="<?= base_url('User'); ?>" class="btn btn-danger">Close</a>
											<button type="submit" class="btn btn-primary">Edit</button>
										</div>
									</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
</div>
