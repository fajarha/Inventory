<div class="content-wrapper">
	<!--content header-->
	<div class="content-header">
		<div class="conteiner fluid">
			<div class="row mb-2">
				<div class="col-sm-6">
					<h1 class="m-0 text-dark"><?= $title; ?></h1>
				</div>
			</div>
		</div>
	</div>

	<section class="content ml-3">
		<div class="row">
			<div class="col-xs-12">
				<div class="box">
					<div class="box-header">
						<h3 class="box-title">Data User</h3>
					</div>
					<!-- /.box-header -->
					<div class="box-body">
						<table id="table1" class="table table-bordered table-hover">
							<thead>
								<tr>
									<th style="width: 5px">No</th>
									<th>Nik</th>
									<th>Nama Lengkap</th>
									<th>Alamat</th>
									<th>Tanggal Lahir</th>
									<th>Username</th>
									<th>Password</th>
									<th>Role</th>
									<th>Action</th>
								</tr>
							</thead>
							<?php $i = 1; ?>
							<?php foreach ($pengguna as $p) : ?>
								<tbody>
									<tr>
										<th scope="row"><?= $i; ?></th>
										<td><?= $p['nik']; ?></td>
										<td><?= $p['nama_lengkap']; ?></td>
										<td><?= $p['alamat']; ?></td>
										<td><?= $p['tanggal_lahir']; ?></td>
										<td><?= $p['username']; ?></td>
										<td><?= $p['password']; ?></td>
										<td><?= $p['role']; ?></td>
										<td>
											<a href="<?= base_url('User/Edit/') . $p['nik']; ?>" class="btn btn-primary btn-sm"><i class="fa fa-edit"></i>&nbsp;Edit</a>
											<a href="<?= base_url('User/Delete/') . $p['nik']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Yakin Ingin Dihapus?');"><i class="fa fa-trash"></i>&nbsp;Delete</a>
										</td>
									</tr>
									<?php $i++; ?>
								<?php endforeach; ?>
								</tbody>
						</table>

					</div>
				</div>
			</div>
		</div>
	</section>
</div>
