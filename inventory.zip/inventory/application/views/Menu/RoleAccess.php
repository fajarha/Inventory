<div class="content-wrapper">
	<!--content header-->
	<div class="content-header">
		<div class="conteiner fluid">
			<div class="row mb-2">
				<div class="col-sm-6">
					<h1 class="m-0 text-dark"><?= $title; ?></h1>
				</div>
			</div>
		</div>
	</div>

	<section class="content ml-3">
		<div class="row">
			<div class="col-xs-12">
				<div class="box">
					<div class="box-header">
						<h3 class="box-title">Data Menu</h3><br><br>
						<h3 class="box-title">Role : <?= $role['role']; ?></h3>
						<?= $this->session->flashdata('pesan'); ?>
					</div>
					<!-- /.box-header -->
					<div class="box-body">
						<table id="#" class="table table-bordered table-hover">
							<thead>
								<tr>
									<th style="width: 5px">No</th>
									<th>Role</th>
									<th>Action</th>
								</tr>
							</thead>
							<?php $i = 1; ?>
							<?php foreach ($menuu as $m) : ?>
								<tbody>
									<tr>
										<th scope="row"><?= $i; ?></th>
										<td><?= $m['menu']; ?></td>
										<td>
											<div class="form-check">
												<input class="form-check-input" type="checkbox" <?= check_access($role['id'], $m['id']); ?> data-role="<?= $role['id']; ?>" data-menu="<?= $m['id']; ?>">
											</div>
										</td>
									</tr>
									<?php $i++; ?>
								<?php endforeach; ?>
								</tbody>
						</table>

					</div>
				</div>
			</div>
		</div>
	</section>
</div>
