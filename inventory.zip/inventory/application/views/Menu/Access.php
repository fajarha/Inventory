<div class="content-wrapper">
	<!--content header-->
	<div class="content-header">
		<div class="conteiner fluid">
			<div class="row mb-2">
				<div class="col-sm-6">
					<h1 class="m-0 text-dark"><?= $title; ?></h1>
				</div>
			</div>
		</div>
	</div>

	<section class="content ml-3">
		<div class="row">
			<div class="col-xs-12">
				<div class="box">
					<div class="box-header">
						<div class="col-sm-6">
							<h3 class="box-title">Data Role</h3>
							<?= $this->session->flashdata('pesan'); ?>
						</div>
						<div class="col-sm-6" align="right">
							<a href="" class="btn btn-primary" data-toggle="modal" data-target="#newRoleModal"><i class="fa fa-plus"></i>&nbsp; Create</a>
						</div>
					</div>
					<!-- /.box-header -->
					<div class="box-body">
						<table id="#" class="table table-bordered table-hover">
							<thead>
								<tr>
									<th style="width: 5px">No</th>
									<th>Role</th>
									<th>Action</th>
								</tr>
							</thead>
							<?php $i = 1; ?>
							<?php foreach ($role as $r) : ?>
								<tbody>
									<tr>
										<th scope="row"><?= $i; ?></th>
										<td><?= $r['role']; ?></td>
										<td>
											<a href="<?= base_url('Menu/RoleAccess/') . $r['id']; ?>" class="btn btn-warning btn-sm"><i class="fa fa-edit"></i>&nbsp;Access</a>
											<a href="" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#newRoleModal<?= $r['id']; ?>">
												<i class="fa fa-edit"></i>&nbsp; Edit</a>
											<a href="<?= base_url('Menu/deleteRole/') . $r['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Yakin Ingin Dihapus?');"><i class="fa fa-trash"></i>&nbsp;Delete</a>
										</td>
									</tr>
									<?php $i++; ?>
								<?php endforeach; ?>
								</tbody>
						</table>

					</div>
				</div>
			</div>
		</div>
	</section>
</div>

<!-- Modal Create Menu-->
<div class="modal fade" id="newRoleModal" tabindex="-1" role="dialog" aria-labelledby="newNamaModalLabel" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="newNamaModalLabel">Create Role</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<form action="<?= base_url('Menu/createRole'); ?>" method="post">
				<div class="modal-body">
					<div class="form-group">
						<input type="text" class="form-control" id="role" name="role" placeholder="Role">
						<?php echo form_error('role'); ?>
					</div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
					<button type="submit" class="btn btn-primary">Create</button>
				</div>
			</form>
		</div>
	</div>
</div>



<!-- Modal Edit Role-->
<?php foreach ($role as $r) : ?>
	<div class="modal fade" id="newRoleModal<?= $r['id']; ?>" tabindex="-1" role="dialog" aria-labelledby="newEditLabel" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title" id="table1Label">Edit Menu</h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
				</div>
				<form action="<?= base_url('Menu/editRole'); ?>" method="post">
					<input type="hidden" name="id" value="<?= $r['id']; ?>">
					<div class="modal-body">
						<div class="form-group">
							<input type="text" class="form-control" id="role" name="role" value="<?= $r['role']; ?>">
							<?php echo form_error('role'); ?>
						</div>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
						<button type="submit" class="btn btn-primary">Edit</button>
					</div>
				</form>
			</div>
		</div>
	</div>
<?php endforeach; ?>
