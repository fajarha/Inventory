<div class="content-wrapper">
	<!--content header-->
	<div class="content-header">
		<div class="conteiner fluid">
			<div class="row mb-2">
				<div class="col-sm-6">
					<h1 class="m-0 text-dark"><?= $title; ?></h1>
				</div>
			</div>
		</div>
	</div>

	<section class="content">
		<div class="row">
			<div class="col-xs-12">
				<div class="box">
					<div class="box-header">
						<div class="col-sm-6">
							<h3 class="box-title">Data Sub Menu</h3>
							<?= $this->session->flashdata('pesan'); ?>
						</div>
						<div class="col-sm-6" align="right">
							<a href="" class="btn btn-primary" data-toggle="modal" data-target="#subMenu"><i class="fa fa-plus"></i>&nbsp; Create</a>
						</div>
					</div> <!-- /.box-header -->
					<div class="box-body table-responsive">
						<table id="table1" class="table table-bordered table-hover">
							<thead>
								<tr>
									<th style="width: 5px">No</th>
									<th>Menu</th>
									<th>Title</th>
									<th>Url</th>
									<th>Iconic</th>
									<th>Is Active</th>
									<th>Action</th>
								</tr>
							</thead>
							<tbody>
								<?php $i = 1; ?>
								<?php foreach ($submenu as $sm) : ?>
									<tr>
										<th scope="row"><?= $i; ?></th>
										<td><?= $sm['menu']; ?></td>
										<td><?= $sm['title']; ?></td>
										<td><?= $sm['url']; ?></td>
										<td><i class="<?= $sm['iconic']; ?>"></i></td>
										<td><?= $sm['is_active']; ?></td>
										<td>
											<a href="" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#newEditModal<?= $sm['id']; ?>">
												<i class="fa fa-edit"></i>&nbsp; Edit</a>
											<a href="<?= base_url('Menu/deleteSubMenu/') . $sm['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Yakin Ingin Dihapus?');"><i class="fa fa-trash"></i>&nbsp;Delete</a>
										</td>
									</tr>
									<?php $i++; ?>
								<?php endforeach; ?>
							</tbody>
						</table>

					</div>
				</div>
			</div>
		</div>
	</section>
</div>

<!-- Modal Create Sub Menu-->
<div class="modal fade" id="subMenu" tabindex="-1" role="dialog" aria-labelledby="newNamaModalLabel" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="newNamaModalLabel">Create Sub Menu</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<form action="<?= base_url('Menu/createSubMenu'); ?>" method="post">
				<div class="modal-body">
					<div class="form-group">
						<select name="menu_id" id="menu_id" class="form-control">
							<option value="">Select Menu</option>
							<?php foreach ($menu as $m) : ?>
								<option value="<?= $m['id']; ?>"><?= $m['menu']; ?></option>
							<?php endforeach; ?>
						</select>
					</div>

					<div class="form-group">
						<input type="text" class="form-control" id="title" name="title" placeholder="Masukan Title">
						<?php echo form_error('title'); ?>
					</div>
					<div class="form-group">
						<input type="text" class="form-control" id="url" name="url" placeholder="Masukan url">
						<?php echo form_error('url'); ?>
					</div>
					<div class="form-group">
						<input type="text" class="form-control" id="iconic" name="iconic" placeholder="Masukan Iconic">
						<?php echo form_error('iconic'); ?>
					</div>
					<div class="form-group">
						<div class="form-check">
							<input class="form-check-input" type="checkbox" id="is_active" name="is_active" value="1" checked>
							<label class="form-check-label" for="is_active"> Active ? </label>
						</div>
					</div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
					<button type="submit" class="btn btn-primary">Create</button>
				</div>
			</form>
		</div>
	</div>
</div>


<!-- Modal Edit Sub Menu-->
<?php foreach ($submenu as $sm) : ?>
	<div class="modal fade" id="newEditModal<?= $sm['id']; ?>" tabindex="-1" role="dialog" aria-labelledby="newEditLabel" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title" id="newNamaModalLabel">Edit Sub Menu</h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
				</div>

				<form action="<?= base_url('Menu/editSubMenu'); ?>" method="post">
					<div class="modal-body">
						<input type="hidden" name="id" value="<?= $sm['id']; ?>">

						<div class="form-group">
							<select name="menu_id" id="menu_id" class="form-control">
								<option value="">Select Menu</option>
								<?php foreach ($menu as $m) : ?>
									<option value="<?= $m['id']; ?>"><?= $m['menu']; ?></option>
								<?php endforeach; ?>
							</select>
						</div>

						<div class="form-group">
							<input type="text" class="form-control" id="title" name="title" value="<?= $sm['title']; ?>">
							<?php echo form_error('title'); ?>
						</div>
						<div class="form-group">
							<input type="text" class="form-control" id="url" name="url" value="<?= $sm['url']; ?>">
							<?php echo form_error('url'); ?>
						</div>
						<div class="form-group">
							<input type="text" class="form-control" id="iconic" name="iconic" value="<?= $sm['iconic']; ?>">
							<?php echo form_error('iconic'); ?>
						</div>
						<div class="form-group">
							<div class="form-check">
								<input class="form-check-input" type="checkbox" id="is_active" name="is_active" value="1" checked>
								<label class="form-check-label" for="is_active"> Active ? </label>
							</div>
						</div>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
						<button type="submit" class="btn btn-primary">Edit</button>
					</div>
				</form>
			</div>
		</div>
	</div>
<?php endforeach; ?>
