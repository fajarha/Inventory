<div class="content-wrapper">
	<!--content header-->
	<div class="content-header">
		<div class="conteiner fluid">
			<div class="row mb-2">
				<div class="col-sm-6">
					<h1 class="m-0 text-dark"><?= $title; ?></h1>
				</div>
			</div>
		</div>
	</div>


	<!-- Main content -->
	<section class="content">
		<form action="<?= base_url('Asset/Receive'); ?>" method="post">
			<div class="row">
				<div class="col-md-12">
					<div class="box box-warning">
						<div class="box-header">
							<h3 class="box-title">Data Konsumen</h3>
							<?= $this->session->flashdata('pesan'); ?>
						</div>
						<div class="box-body">
							<div class="col-lg-2 <?php echo form_error('nik') ? 'has-error' : null; ?>">
								<label for="nik">NIK</label>
								<input type="text" class="form-control" id="nik" name="nik" placeholder="NIK" value="<?= set_value('nik'); ?>">
								<?php echo form_error('nik'); ?>
							</div>

							<div class="col-lg-2 <?php echo form_error('nama_customer') ? 'has-error' : null; ?>">
								<label for="nama_customer">Nama Costumer</label>
								<input type="text" class="form-control" id="nama_customer" name="nama_customer" placeholder="Nama Customer" value="<?= set_value('nama_customer'); ?>">
								<?php echo form_error('nama_customer'); ?>
							</div>

							<div class="col-lg-3 <?php echo form_error('no_aggrement') ? 'has-error' : null; ?>">
								<label for="no_aggrement">No Aggrement</label>
								<input type="text" class="form-control" id="no_aggrement" name="no_aggrement" placeholder="No Aggrement" value="<?= set_value('no_aggrement'); ?>">
								<?php echo form_error('no_aggrement'); ?>
							</div>

							<div class="col-lg-2 <?php echo form_error('ovd') ? 'has-error' : null; ?>">
								<label for="ovd">Overdue</label>
								<input type="text" class="form-control" id="ovd" name="ovd" placeholder="Overdue" value="<?= set_value('ovd'); ?>">
								<?php echo form_error('ovd'); ?>
							</div>

							<div class="col-lg-3 <?php echo form_error('status_konsumen') ? 'has-error' : null; ?>">
								<label for="status_konsumen">Status Konsumen</label>
								<select name="status_konsumen" id="status_konsumen" class="form-control" value="<?= set_value('status_konsumen'); ?>">
									<option>Select Status Konsumen</option>
									<option value="Normal">Normal</option>
									<option value="Wo">Wo</option>
								</select>
								<?php echo form_error('status_konsumen'); ?>
							</div>
						</div>

					</div>
				</div>
			</div>


			<div class="row">
				<div class="col-md-12">

					<div class="box box-warning">
						<div class="box-header">
							<h3 class="box-title">Spesifikasi Barang</h3>
						</div>
						<div class="box-body">
							<div class="form-group row">
								<div class="col-lg-3 <?php echo form_error('kategori') ? 'has-error' : null; ?>">
									<label for="kategori">Kategori</label>
									<select name="kategori" id="kategori" class="form-control" value="<?= set_value('kategori'); ?>">
										<option>Select Kategori</option>
										<option value="KMB">KMB</option>
										<option value="KMOB">KMOB</option>
										<option value="WG">WG</option>
									</select>
									<?php echo form_error('kategori'); ?>
								</div>

								<div class="col-lg-3 <?php echo form_error('merk') ? 'has-error' : null; ?>">
									<label for="merk">Merk</label>
									<input type="text" class="form-control" id="merk" name="merk" placeholder="Merk" value="<?= set_value('merk'); ?>">
									<?php echo form_error('merk'); ?>
								</div>

								<div class="col-lg-3">
									<label for="no_rangka">No Rangka</label>
									<input type="text" class="form-control" id="no_rangka" name="no_rangka" placeholder="No Rangka" value="<?= set_value('no_rangka'); ?>">
									<?php echo form_error('no_rangka'); ?>
								</div>

								<div class="col-lg-3">
									<label for="no_serial">No Serial</label>
									<input type="text" class="form-control" id="no_serial" name="no_serial" placeholder="No Serial" value="<?= set_value('no_serial'); ?>">
									<?php echo form_error('no_serial'); ?>
								</div>
							</div>

							<div class="form-group row">
								<div class="col-lg-3">
									<label for="no_mesin">No Mesin</label>
									<input type="text" class="form-control" id="no_mesin" name="no_mesin" placeholder="No Mesin" value="<?= set_value('no_mesin'); ?>">
									<?php echo form_error('no_mesin'); ?>
								</div>

								<div class="col-lg-3">
									<label for="no_polisi">No Polisi</label>
									<input type="text" class="form-control" id="no_polisi" name="no_polisi" placeholder="No Polisi" value="<?= set_value('no_polisi'); ?>">
									<?php echo form_error('no_polisi'); ?>
								</div>

								<div class="col-lg-3">
									<label for="warna">Warna</label>
									<input type="text" class="form-control" id="warna" name="warna" placeholder="Warna" value="<?= set_value('warna'); ?>">
									<?php echo form_error('warna'); ?>
								</div>

								<div class="col-lg-3 <?php echo form_error('status_barang') ? 'has-error' : null; ?>">
									<label for="status_barang">Status Barang</label>
									<select name="status_barang" id="status_barang" class="form-control" value="<?= set_value('status_barang'); ?>">
										<option>Select Status Barang</option>
										<option value="Reposes">Reposess</option>
										<option value="Inventory">Inventory</option>
									</select>
									<?php echo form_error('status_barang'); ?>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>

			<div class="row">
				<div class="col-md-6">
					<div class="box box-warning">

						<div class="box-header">
							<h3 class="box-title">Harga Barang</h3>
						</div>

						<div class="box-body">
							<div class="form-group row">
								<div class="col-lg-4 <?php echo form_error('otr') ? 'has-error' : null; ?>">
									<label for="otr">OTR</label>
									<input type="text" class="form-control" id="otr" name="otr" placeholder="OTR" value="<?= set_value('otr'); ?>">
									<?php echo form_error('otr'); ?>
								</div>


								<div class="col-lg-4 <?php echo form_error('nilai_barang') ? 'has-error' : null; ?>">
									<label for="nilai_barang">Nilai Barang</label>
									<input type="text" class="form-control" id="nilai_barang" name="nilai_barang" placeholder="Nilai Barang" value="<?= set_value('nilai_barang'); ?>">
									<?php echo form_error('nilai_barang'); ?>
								</div>

								<div class="col-lg-4 <?php echo form_error('biaya_tarik') ? 'has-error' : null; ?>">
									<label for="biaya_tarik">Biaya Tarik</label>
									<input type="text" class="form-control" id="biaya_tarik" name="biaya_tarik" placeholder="Biaya Tarik" value="<?= set_value('biaya_tarik'); ?>">
									<?php echo form_error('biaya_tarik'); ?>
								</div>
							</div>

							<div class="form-group row">

								<div class="col-lg-4 <?php echo form_error('nilai_denda') ? 'has-error' : null; ?>">
									<label for="nilai_denda">Nilai Denda</label>
									<input type="text" class="form-control" id="nilai_denda" name="nilai_denda" placeholder="Nilai Denda" value="<?= set_value('nilai_denda'); ?>">
									<?php echo form_error('nilai_denda'); ?>
								</div>

								<div class="col-lg-4 <?php echo form_error('sisa_denda') ? 'has-error' : null; ?>">
									<label for="sisa_denda">Sisa Denda</label>
									<input type="text" class="form-control" id="sisa_denda" name="sisa_denda" placeholder="Sisa Denda" value="<?= set_value('sisa_denda'); ?>">
									<?php echo form_error('sisa_denda'); ?>
								</div>


								<div class="col-lg-4 <?php echo form_error('nik_collector') ? 'has-error' : null; ?>">
									<label for="nik_collector">NIK Collector</label>
									<input type="text" class="form-control" id="nik_collector" name="nik_collector" placeholder="Nik Collector" value="<?= set_value('nik_collector'); ?>">
									<?php echo form_error('nik_collector'); ?>
								</div>
							</div>

							<div class="form-group row">
								<div class="col-lg-4 <?php echo form_error('nama_collector') ? 'has-error' : null; ?>">
									<label for="nama_collector">Nama Collector</label>
									<input type="text" class="form-control" id="nama_collector" name="nama_collector" placeholder="Petugas Collector" value="<?= set_value('nama_collector'); ?>">
									<?php echo form_error('nama_collector'); ?>
								</div>

								<div class="col-lg-4 <?php echo form_error('lokasi') ? 'has-error' : null; ?>">
									<label for="lokasi">Lokasi Barang</label>
									<input type="text" class="form-control" id="lokasi" name="lokasi" placeholder="Lokasi Barang" value="<?= set_value('lokasi'); ?>">
									<?php echo form_error('lokasi'); ?>
								</div>
							</div>

						</div>
					</div>
				</div>

				<div class="col-md-6">
					<div class="box box-warning">

						<div class="box-header">
							<h3 class="box-title">Deskripsi Barang</h3>
						</div>

						<div class="box-body">

							<div class="form-group row">
								<div class="col-lg-5 ">
									<label for="tanggal_stnk">Tanggal Stnk</label>
									<div class="input-group date">
										<div class="input-group-addon">
											<i class="fa fa-calendar"></i>
										</div>
										<input type="text" class="form-control pull-right" id="datepicker" name="tanggal_stnk" placeholder="yyyy-mm-dd" value="<?= set_value('tanggal_stnk'); ?>">
									</div>
									<?php echo form_error('tanggal_stnk'); ?>
								</div>

								<div class="col-lg-5">
									<label for="tanggal_pajak">Tanggal Pajak</label>
									<div class="input-group date">
										<div class="input-group-addon">
											<i class="fa fa-calendar"></i>
										</div>
										<input type="text" class="form-control pull-right" id="tgl" name="tanggal_pajak" placeholder="yyyy-mm-dd" value="<?= set_value('tanggal_pajak'); ?>">
									</div>
									<?php echo form_error('tanggal_pajak'); ?>
								</div>
							</div>

							<div class="form-group row">

								<div class="col-lg-5 <?php echo form_error('deskripsi_barang') ? 'has-error' : null; ?>">
									<label for="deskripsi_barang">Deskripsi Barang</label>
									<textarea class="form-control" id="deskripsi_barang" name="deskripsi_barang" placeholder="Silahkan Masukan Deskripsi" value="<?= set_value('deskripsi_barang'); ?>"></textarea>
									<?php echo form_error('deskripsi_barang'); ?>
								</div>

								<div class="col-lg-5 pt-5" align="right">
									<a href="<?= base_url(''); ?>" class="btn btn-danger">Close</a>
									<button type="submit" class="btn btn-primary">Save</button>
								</div>
							</div>

						</div>
					</div>
				</div>
			</div>
		</form>
	</section>
</div>
