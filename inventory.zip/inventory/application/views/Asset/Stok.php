<div class="content-wrapper">
	<!--content header-->
	<div class="content-header">
		<div class="conteiner fluid">
			<div class="row mb-2">
				<div class="col-sm-6">
					<h1 class="m-0 text-dark"><?= $title; ?></h1>
				</div>
			</div>
		</div>
	</div>

	<section class="content ml-3">
		<div class="row">
			<div class="col-xs-12">
				<div class="box">
					<!-- /.box-header -->
					<div class="box-body">
						<table id="table1" class="table table-bordered table-hover">
							<thead>
								<tr>
									<th style="width: 5px">No</th>
									<th>Kode Barang</th>
									<th>Nama Customer</th>
									<th>Merk Barang</th>
									<th>OTR</th>
									<th>Umur Barang</th>
									<th>Status Barang</th>
									<th>Action</th>
								</tr>
							</thead>
							<?php $i = 1; ?>
							<?php foreach ($barang as $b) : ?>
								<tbody>
									<tr>
										<th scope="row"><?= $i; ?></th>
										<td><?= $b['kd_barang']; ?></td>
										<td><?= $b['nama_customer']; ?></td>
										<td><?= $b['merk']; ?> | <?= $b['no_polisi']; ?></td>
										<td>
											<?php
											$harga = $b['otr'];
											echo "Rp. " . number_format($harga, 2, ",", ".");
											?>
										</td>
										<td><?php
											$tgl1 = new DateTime($b['umur_barang']);
											$tgl2 = new DateTime();
											$selisih = $tgl2->diff($tgl1)->format("%a");;

											echo $selisih;
											?> Hari</td>
										<td><?= $b['status_barang']; ?></td>
										<td>
											<a href="<?= base_url('Asset/detailAsset/') . $b['kd_barang']; ?>" class="btn btn-success btn-sm"><i class="fa fa-info"></i>&nbsp;Detail</a>
											<a href="<?= base_url('Asset/editBrg/') . $b['kd_barang']; ?>" class="btn btn-primary btn-sm"><i class="fa fa-edit"></i>&nbsp;Edit</a>
											<a href=" <?= base_url('Asset/stikerBrg/') . $b['kd_barang']; ?>" target="_blank" class="btn btn-warning btn-sm"><i class="fa fa-file"></i>&nbsp;stiker</a>
										</td>
									</tr>
									<?php $i++; ?>
								<?php endforeach; ?>
								</tbody>
						</table>

					</div>
				</div>
			</div>
		</div>
	</section>


</div>
