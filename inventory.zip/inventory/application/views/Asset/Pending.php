<div class="content-wrapper">
	<!--content header-->
	<div class="content-header">
		<div class="conteiner fluid">
			<div class="row mb-2">
				<div class="col-sm-6">
					<h1 class="m-0 text-dark"><?= $title; ?></h1>
				</div>
			</div>
		</div>
	</div>

	<section class="content ml-3">
		<div class="row">
			<div class="col-xs-12">
				<div class="box">
					<!-- /.box-header -->
					<div class="box-body">

						<?= $this->session->flashdata('pesan'); ?>
						<table id="" class="table table-bordered table-hover">
							<thead>
								<tr>
									<th style="width: 5px">No</th>
									<th>Nik Pembeli</th>
									<th>Nama Pembeli</th>
									<th>Barang</th>
									<th>Harga Pembelian</th>
									<th>Keterangan</th>
									<th>Tanggal Pembelian</th>
									<th>Action</th>
								</tr>
							</thead>
							<?php $i = 1; ?>
							<?php foreach ($pending as $p) : ?>
								<tbody>
									<tr>
										<th scope="row"><?= $i; ?></th>
										<td><?= $p['nik_pembeli']; ?></td>
										<td><?= $p['nama_pembeli']; ?></td>
										<td><a href="<?= base_url('Asset/DetailAsset/') . $p['kd_barang']; ?>"><?= $p['kd_barang']; ?></td>
										<td><?php
											$harga = $p['harga_pembelian'];
											echo "Rp. " . number_format($harga, 2, ".", ",");
											?></td>
										<td><?= $p['keterangan']; ?></td>
										<td><?php
											$format = date('d-m-Y', strtotime($p['tanggal_pembelian']));
											echo $format; ?></td>
										<td>
											<a href="" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#newRoleModal<?= $p['id_pending']; ?>">
												<i class="fa fa-edit"></i>&nbsp; Ajukan Kembali</a>
										</td>
									</tr>
									<?php $i++; ?>
								<?php endforeach; ?>
								</tbody>
						</table>

					</div>
				</div>
			</div>
		</div>
	</section>
</div>

<!-- Modal Pending-->
<?php foreach ($pending as $a) : ?>
	<div class="modal fade" id="newRoleModal<?= $a['id_pending']; ?>" tabindex="-1" role="dialog" aria-labelledby="newEditLabel" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title" id="table1Label">Penjualan Asset</h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
				</div>
				<form action="<?= base_url('Transaksi/PenjualanAct'); ?>" method="post">

					<div class="modal-body">
						<input type="hidden" name="id_pending" value="<?= $a['id_pending']; ?>">
						<div class="form-group">
							<input type="text" class="form-control" id="nik_pembeli" name="nik_pembeli" value="<?= $a['nik_pembeli']; ?>">
						</div>

						<div class="form-group">
							<input type="text" class="form-control" id="nama_pembeli" name="nama_pembeli" value="<?= $a['nama_pembeli']; ?>">

						</div>

						<div class="form-group">
							<input type="text" class="form-control" id="kode_barang" name="kode_barang" value="<?= $a['kd_barang']; ?>">

						</div>

						<div class="form-group">
							<input type="text" class="form-control" id="harga_pembelian" name="harga_pembelian" value="<?= $a['harga_pembelian']; ?>">

						</div>

						<div class="form-group">
							<input type="text" class="form-control" id="tanggal_pembelian" name="tanggal_pembelian" value="<?= $a['tanggal_pembelian']; ?>">

						</div>

					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
						<button type="submit" class="btn btn-primary">Save</button>
					</div>
				</form>
			</div>
		</div>
	</div>
<?php endforeach; ?>
