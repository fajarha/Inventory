<div class="content-wrapper">
	<!--content header-->
	<div class="content-header">
		<div class="conteiner fluid">
			<div class="row mb-2">
				<div class="col-sm-6">
					<h1 class="m-0 text-dark"><?= $title; ?></h1>
				</div>
			</div>
		</div>
	</div>

	<section class="content ml-3">
		<div class="row">
			<div class="col-xs-12">
				<div class="box">

					<div class="box-body">
						<table class="table table-bordered ">
							<tr align="center" bgcolor="#FFEFD5">
								<td height="20px" colspan="6">
									<p><b>Asset View</b></p>
								</td>
							</tr>


							<tr>
								<td bgcolor="#FFFAFA">Nik</td>
								<td colspan="6" bgcolor=""><?= $nik; ?></td>
							</tr>

							<tr>
								<td bgcolor="#FFFAFA">Nama Customer</td>

								<td colspan="6" bgcolor=""><?= $nama_customer; ?></td>
							</tr>
							<tr>
								<td bgcolor="	#FFFAFA">No Aggrement</td>

								<td colspan="6" bgcolor=""><?= $no_aggrement; ?></td>
							</tr>

							<tr>
								<td bgcolor="	#FFFAFA">Status Konsumen</td>

								<td colspan="6" bgcolor=""><?= $status_konsumen; ?></td>
							</tr>

							<tr>
								<td bgcolor="	#FFFAFA">OVD</td>
								<td colspan="6" bgcolor=""><?= $ovd; ?></td>
							</tr>

							<tr>
								<td colspan="6" bgcolor="#DCDCDC"></td>
							</tr>

							<tr align="center">
								<td bgcolor="#FFFAF"><b>Kategori Barang</b></td>
								<td bgcolor="#FFFAF"><b>OTR</b></td>
								<td bgcolor="#FFFAF"><b>Nilai Barang</b></td>
								<td bgcolor="#FFFAF"><b>Nilai Denda</b></td>
								<td bgcolor="#FFFAF"><b>Sisa Denda</b></td>
								<td bgcolor="#FFFAF"><b>Status Barang</b></td>
							</tr>

							<tr align="center">
								<td bgcolor=""><?= $kategori; ?></td>
								<td bgcolor="">
									<?php
									$harga = $otr;
									echo "Rp. " . number_format($harga, 2, ".", ",");
									?>
								</td>
								<td bgcolor="">
									<?php
									$harga = $nilai_barang;
									echo "Rp. " . number_format($harga, 2, ".", ",");
									?>
								</td>
								<td bgcolor="">
									<?php
									$harga = $nilai_denda;
									echo "Rp. " . number_format($harga, 2, ".", ",");
									?>
								</td>
								<td bgcolor="">
									<?php
									$harga = $sisa_denda;
									echo "Rp. " . number_format($harga, 2, ".", ",");
									?>
								</td>
								<td bgcolor=""><?= $status_barang; ?></td>
							</tr>

							<tr>
								<td colspan="6"><b>Spesifikasi Barang</b></td>
							</tr>

							<tr>
								<td bgcolor="#FFFAFA">Merk</td>
								<td bgcolor="" colspan="2"><?= $merk; ?></td>

								<td bgcolor="#FFFAFA">No Rangka</td>
								<td bgcolor="" colspan="2"><?= $no_rangka; ?></td>
							</tr>

							<tr>
								<td bgcolor="#FFFAFA">No Mesin</td>
								<td bgcolor="" colspan="2"><?= $no_mesin; ?></td>

								<td bgcolor="#FFFAFA">No Polisi</td>
								<td bgcolor="" colspan="2"><?= $no_polisi; ?></td>
							</tr>

							<tr>
								<td bgcolor="#FFFAFA">No Serial</td>
								<td bgcolor="" colspan="2"><?= $no_serial; ?></td>

								<td bgcolor="#FFFAFA">Warna</td>
								<td bgcolor="" colspan="2"><?= $warna; ?></td>
							</tr>

							<tr>
								<td bgcolor="#FFFAFA">Umur Barang</td>
								<td bgcolor="" colspan="2">
									<?php
									$tgl1 = new DateTime($umur_barang);
									$tgl2 = new DateTime();
									$selisih = $tgl2->diff($tgl1)->format("%a");;

									echo $selisih;
									?> Hari
								</td>

								<td bgcolor="#FFFAFA">Lokasi Barang</td>
								<td bgcolor="" colspan="2"><?= $lokasi; ?></td>
							</tr>

							<tr>
								<td bgcolor="#FFFAFA">Tanggal Stnk</td>
								<td bgcolor="" colspan="2">
									<?php
									$format = date('d-m-Y', strtotime($tanggal_stnk));
									echo $format; ?>
								</td>

								<td bgcolor="#FFFAFA">Tanggal Pajak</td>
								<td bgcolor="" colspan="2">
									<?php
									$format = date('d-m-Y', strtotime($tanggal_pajak));
									echo $format; ?>
								</td>
							</tr>

							<tr>
								<td colspan="6"><b>Petugas Penarikan Barang</b></td>
							</tr>

							<tr>
								<td bgcolor="#FFFAFA">Biaya Tarik</td>
								<td bgcolor="" colspan="6">
									<?php
									$harga = $biaya_tarik;
									echo "Rp. " . number_format($harga, 2, ".", ",");
									?>
								</td>
							</tr>


							<tr>
								<td bgcolor="#FFFAFA">Nik Collector</td>
								<td bgcolor="" colspan="6"><?= $nik_collector; ?></td>
							</tr>

							<tr>
								<td bgcolor="#FFFAFA">Nama Collector</td>
								<td bgcolor="" colspan="6"><?= $nama_collector; ?></td>
							</tr>

							<tr>
								<td bgcolor="#FFFAFA">Deskripsi Barang</td>
								<td bgcolor="" colspan="6"><?= $deskripsi_barang; ?></td>
							</tr>
						</table>
					</div>
				</div>
			</div>
		</div>
	</section>
</div>
