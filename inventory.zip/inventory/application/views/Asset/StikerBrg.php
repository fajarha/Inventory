<!DOCTYPE html>
<html lang="en"><head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title><?= $title; ?></title>
	<style type="text/css">
		.table{
			margin-left: 40px;
		}
	</style>

</head><body>
	<table class="table">
		<tr colspan="5" align="right">
			
			<td><?= $nama_customer; ?></td>
		</tr>
		<tr colspan="5" align="right">
			
			<td><?= $no_aggrement; ?></td>
		</tr>
		<tr colspan="5" align="right">
				
			<td><?= $merk; ?></td>
		</tr>
		<tr colspan="5" align="right">
			
			<td><?= $no_rangka; ?></td>
		</tr>
		<tr colspan="5" align="right">
			
			<td><?= $no_mesin; ?></td>
		</tr>
		<tr colspan="5" align="right">
			
			<td><?= $no_polisi; ?></td>
		</tr>
	</table>


</body></html>
