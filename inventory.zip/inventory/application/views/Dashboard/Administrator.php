<div class="content-wrapper">
	<!--content header-->
	<div class="content-header">
		<div class="conteiner fluid">
			<div class="row mb-2">
				<div class="col-sm-6">
					<h1 class="m-0 text-dark"><?= $title; ?></h1>
				</div>
			</div>
		</div>
	</div>

	<!--content-->
	<section class="content">
		<div class="container-fluid">

			<!--box-->
			<div class="row">
				<div class="col-lg-4 col-6">
					<div class="small-box bg-green">
						<div class="inner">
							<h3>20</h3>

							<p>Penjualan Barang</p>
						</div>
						<div class="icon">
							<i class="ion ion-bag"></i>
						</div>
						<a href="#" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
					</div>
				</div>

				<div class="col-lg-4 col-6">
					<div class="small-box bg-blue">
						<div class="inner">
							<h3>10</h3>
							<p>Barang Masuk</p>
						</div>
						<div class="icon">
							<i class="ion ion-stats-bars"></i>
						</div>
						<a href="#" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
					</div>
				</div>

				<div class="col-lg-4 col-6">
					<div class="small-box bg-red">
						<div class="inner">
							<h3>10</h3>

							<p>Stok Barang</p>
						</div>
						<div class="icon">
							<i class="ion ion-pie-graph"></i>
						</div>
						<a href="#" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
					</div>
				</div>

			</div>


		</div>
	</section>

</div>
