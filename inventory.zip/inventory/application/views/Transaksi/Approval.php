<div class="content-wrapper">
	<!--content header-->
	<div class="content-header">
		<div class="conteiner fluid">
			<div class="row mb-2">
				<div class="col-sm-6">
					<h1 class="m-0 text-dark"><?= $title; ?></h1>
				</div>
			</div>
		</div>
	</div>

	<section class="content ml-3">
		<div class="row">
			<div class="col-xs-12">
				<div class="box">
					<!-- /.box-header -->
					<div class="box-body">

						<?= $this->session->flashdata('pesan'); ?>
						<table id="" class="table table-bordered table-hover">
							<thead>
								<tr>
									<th style="width: 5px">No</th>
									<th>Nik Pembeli</th>
									<th>Nama Pembeli</th>
									<th>Barang</th>
									<th>Harga Pembelian</th>
									<th>Persentase</th>
									<th>Tanggal Pembelian</th>
									<th>Action</th>
								</tr>
							</thead>
							<?php $i = 1; ?>
							<?php foreach ($approval as $a) : ?>
								<tbody>
									<tr>
										<th scope="row"><?= $i; ?></th>
										<td><?= $a['nik_pembeli']; ?></td>
										<td><?= $a['nama_pembeli']; ?></td>
										<td><a href="<?= base_url('Asset/DetailAsset/') . $a['kd_barang']; ?>"><?= $a['kd_barang']; ?></td>
										<td><?php
											$harga = $a['harga_pembelian'];
											echo "Rp. " . number_format($harga, 2, ".", ",");
											?></td>
										<td>Persentase</td>
										<td><?php
											$format = date('d-m-Y', strtotime($a['tanggal_pembelian']));
											echo $format; ?></td>
										<td>
											<a href="<?= base_url('Transaksi/ApproveAct/') . $a['id_approval']; ?>" class="btn btn-primary btn-sm"><i class="fa fa-edit"></i>&nbsp;Approve</a>
											<a href="" class="btn btn-danger btn-sm" data-toggle="modal" data-target="#newRoleModal<?= $a['id_approval']; ?>">
												<i class="fa fa-history"></i>&nbsp; Pending</a>
										</td>
									</tr>
									<?php $i++; ?>
								<?php endforeach; ?>
								</tbody>
						</table>

					</div>
				</div>
			</div>
		</div>
	</section>
</div>


<!-- Modal Approval-->
<?php foreach ($approval as $a) : ?>
	<div class="modal fade" id="newRoleModal<?= $a['id_approval']; ?>" tabindex="-1" role="dialog" aria-labelledby="newEditLabel" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title" id="table1Label">Pending Penjualan</h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
				</div>
				<form action="<?= base_url('Transaksi/PendingAct'); ?>" method="post">

					<div class="modal-body">
						<input type="hidden" name="id_approval" value="<?= $a['id_approval']; ?>">
						<div class="form-group">
							<input type="text" class="form-control" id="nik_pembeli" name="nik_pembeli" value="<?= $a['nik_pembeli']; ?>">
						</div>

						<div class="form-group">
							<input type="text" class="form-control" id="nama_pembeli" name="nama_pembeli" value="<?= $a['nama_pembeli']; ?>">

						</div>

						<div class="form-group">
							<input type="text" class="form-control" id="kode_barang" name="kode_barang" value="<?= $a['kd_barang']; ?>">

						</div>

						<div class="form-group">
							<input type="text" class="form-control" id="harga_pembelian" name="harga_pembelian" value="<?= $a['harga_pembelian']; ?>">

						</div>

						<div class="form-group">
							<input type="text" class="form-control" id="tanggal_pembelian" name="tanggal_pembelian" value="<?= $a['tanggal_pembelian']; ?>">

						</div>

						<div class="form-group">
							<textarea class="form-control" id="keterangan" name="keterangan" placeholder="Silahkan Masukan Keterangan"></textarea>

						</div>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
						<button type="submit" class="btn btn-primary">Save</button>
					</div>
				</form>
			</div>
		</div>
	</div>
<?php endforeach; ?>
