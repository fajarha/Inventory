<div class="content-wrapper">
	<!--content header-->
	<div class="content-header">
		<div class="conteiner fluid">
			<div class="row mb-2">
				<div class="col-sm-6">
					<h1 class="m-0 text-dark"><?= $title; ?></h1>
				</div>
			</div>
		</div>
	</div>

	<!-- Main content -->
	<section class="content">
		<form action="<?= base_url('Transaksi/Penjualan'); ?>" method="post">
			<div class="row mb-3">
				<div class="col-md-12">
					<div class="box box-warning">
						<div class="box-body">

							<?= $this->session->flashdata('pesan'); ?>
							<div class="form-group row">
								<div class="col-lg-2 ">
									<label for="nik_pembeli">NIK Pembeli</label>
								</div>

								<div class="col-lg-4 <?php echo form_error('nik_pembeli') ? 'has-error' : null; ?>">
									<input type="text" class="form-control" id="nik_pembeli" name="nik_pembeli" placeholder="NIK Pembeli">
									<?php echo form_error('nik_pembeli'); ?>
								</div>
							</div>

							<div class="form-group row">
								<div class="col-lg-2 ">
									<label for="nama_pembeli">Nama Pembeli</label>
								</div>

								<div class="col-lg-4 <?php echo form_error('nama_pembeli') ? 'has-error' : null; ?>">
									<input type="text" class="form-control" id="nama_pembeli" name="nama_pembeli" placeholder="Nama Pembeli">
									<?php echo form_error('nama_pembeli'); ?>
								</div>
							</div>

							<div class="form-group row">
								<div class="col-lg-2 ">
									<label for="kode_barang">Kode Barang</label>
								</div>

								<div class="col-lg-4 <?php echo form_error('kode_barang') ? 'has-error' : null; ?>">
									<input type="text" class="form-control" id="kode_barang" name="kode_barang" placeholder="Kode Barang">
									<?php echo form_error('kode_barang'); ?>
								</div>
							</div>

							<div class="form-group row">
								<div class="col-lg-2">
									<label for="harga_pembelian">Harga Pembelian</label>

								</div>

								<div class=" col-lg-4  <?php echo form_error('harga_pembelian') ? 'has-error' : null; ?>">
									<input type="text" class="form-control" id="harga_pembelian" name="harga_pembelian" placeholder="Harga Pembelian">
									<?php echo form_error('harga_pembelian'); ?>
								</div>
							</div>
						</div>

						<div class="form-group row ">
							<div class="col-lg-6 pt-5" align="right">
								<a href="<?= base_url('Asset/Stok'); ?>" class="btn btn-danger">Close</a>
								<button type="submit" class="btn btn-primary">Save</button>
							</div>
						</div>

						<div class="form-group row">
						</div>

					</div>
				</div>
			</div>

		</form>
	</section>
</div>
