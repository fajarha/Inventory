<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title><?= $title; ?></title>
	<style type="text/css">
		.table {
			margin-left: 40px;
		}
	</style>

</head>

<body>
	<table class="table ">
		<tr colspan="5" align="right">

			<td><?= $no_kwitansi; ?></td>
		</tr>
		<tr colspan="5" align="right">

			<td><?= $kd_barang; ?></td>
		</tr>
		<tr colspan="5" align="right">

			<td><?= $invoice; ?></td>
		</tr>
		<tr colspan="5" align="right">

			<td><?= $nama_pembeli; ?></td>
		</tr>
		<tr colspan="5" align="right">

			<td>
				<?php
				$harga = $harga_pembelian;
				echo "Rp. " . number_format($harga, 2, ".", ",");
				?>
			</td>
		</tr>
		<tr colspan="5" align="right">

			<td>
				<?php
				$harga = $jumlah_pembayaran;
				echo "Rp. " . number_format($harga, 2, ".", ",");
				?>
			</td>
		</tr>

		<tr colspan="5" align="right">

			<td><?php
				$format = date('d-m-Y', strtotime($tanggal_pembayaran));
				echo $format; ?></td>
		</tr>
	</table>

	<script type="text/javascript">
		window.print();
	</script>
</body>

</html>
