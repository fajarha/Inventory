<div class="content-wrapper">
	<!--content header-->
	<div class="content-header">
		<div class="conteiner fluid">
			<div class="row mb-2">
				<div class="col-sm-6">
					<h1 class="m-0 text-dark"><?= $title; ?></h1>
				</div>
			</div>
		</div>
	</div>

	<section class="content ml-3">
		<div class="row">
			<div class="col-xs-12">
				<div class="box">
					<!-- /.box-header -->
					<div class="box-body">
						<table id="table1" class="table table-bordered table-hover">
							<thead>
								<tr>
									<th style="width: 5px">No</th>
									<th>Kode Barang</th>
									<th>Invoice</th>
									<th>Nama Pembeli</th>
									<th>Nik Pembeli</th>
									<th>Jumlah Pembelian</th>
									<th>Action</th>
								</tr>
							</thead>
							<?php $i = 1; ?>
							<?php foreach ($terjual as $t) : ?>
								<tbody>
									<tr>
										<th scope="row"><?= $i; ?></th>
										<td><?= $t['kd_barang']; ?></td>
										<td><?= $t['invoice']; ?></td>
										<td><?= $t['nik_pembeli']; ?></td>
										<td><?= $t['nama_pembeli']; ?></td>
										<td>
											<?php
											$harga = $t['harga_pembelian'];
											echo "Rp. " . number_format($harga, 2, ",", ".");
											?>
										</td>
										<td><a href="" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#newBayarModal<?= $t['invoice']; ?>">
												<i class="fa fa-edit"></i>&nbsp; Bayar</a></td>
									</tr>
									<?php $i++; ?>
								<?php endforeach; ?>
								</tbody>
						</table>

					</div>
				</div>
			</div>
		</div>
	</section>

</div>

<!-- Modal Bayar-->
<?php foreach ($terjual as $t) : ?>
	<div class="modal fade" id="newBayarModal<?= $t['invoice']; ?>" tabindex="-1" role="dialog" aria-labelledby="newInvoiceLabel" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title" id="table1Label">Bayar</h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
				</div>
				<form action="<?= base_url('Pembayaran/Bayar'); ?>" method="post">

					<div class="modal-body">
						<div class="form-group">
							<input type="text" class="form-control" id="kd_barang" name="kd_barang" value="<?= $t['kd_barang']; ?>">
							<?php echo form_error('kd_barang'); ?>
						</div>
						<div class="form-group">
							<input type="text" class="form-control" id="invoice" name="invoice" value="<?= $t['invoice']; ?>">
							<?php echo form_error('invoice'); ?>
						</div>
						<div class="form-group">
							<input type="text" class="form-control" id="jumlah_pembayaran" name="jumlah_pembayaran" placeholder="Masukan Jumlah Uang">
							<?php echo form_error('jumlah_pembayaran'); ?>
						</div>
					</div>


					<div class="modal-footer">
						<button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
						<button type="submit" target="_blank" class="btn btn-primary">Bayar</button>
					</div>
				</form>
			</div>
		</div>
	</div>
<?php endforeach; ?>
