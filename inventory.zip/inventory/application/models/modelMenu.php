<?php
defined('BASEPATH') or exit('No direct script access allowed');

class modelMenu extends CI_Model
{
	public function tampilMenu()
	{
		$data  = $this->db->get('user_menu');
		return $data->result_array();
	}

	public function tambahMenu($data = null)
	{
		$this->db->insert('user_menu', $data);
	}

	public function editMenu($id, $data)
	{
		$this->db->where('id', $id);
		$this->db->update('user_menu', $data);
	}

	public function deleteMenu($id)
	{
		$this->db->where('id', $id);
		$this->db->delete('user_menu');
	}

	public function tambahSubMenu($data = null)
	{
		$this->db->insert('user_sub_menu', $data);
	}

	public function editSubMenu($id, $data)
	{
		$this->db->where('id', $id);
		$this->db->update('user_sub_menu', $data);
	}

	public function deleteSubMenu($id)
	{
		$this->db->where('id', $id);
		$this->db->delete('user_sub_menu');
	}

	public function joinSubMenu()
	{
		$query = "SELECT `user_sub_menu`.* , `user_menu`.`menu`
				FROM `user_sub_menu` JOIN `user_menu` 
				ON `user_sub_menu`.`menu_id` = `user_menu`.`id` 
				";
		return $this->db->query($query)->result_array();
	}

	public function joinAccess()
	{
		$this->db->select('*');
		$this->db->from('user_access_menu');
		$this->db->join('role', 'user_access_menu.role_id = role.id');
		$this->db->join('user_menu', 'user_access_menu.menu_id = user_menu.id');
		return $this->db->get()->result_array();
	}

	public function tampilRole()
	{
		$data  = $this->db->get('role');
		return $data->result_array();
	}

	public function editRole($id, $data)
	{
		$this->db->where('id', $id);
		$this->db->update('role', $data);
	}

	public function deleteRole($id)
	{
		$this->db->where('id', $id);
		$this->db->delete('role');
	}

	public function tambahRole($data = null)
	{
		$this->db->insert('role', $data);
	}
}
