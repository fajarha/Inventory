<?php
defined('BASEPATH') or exit('No direct script access allowed');

class modelBayar extends CI_Model
{
	public function simpanBayar($data = null)
	{
		$this->db->insert('pembayaran', $data);
	}

	public function tampilCetakBayar()
	{
		$this->db->select('*');
		$this->db->from('pembayaran');
		$this->db->join('penjualan_barang', 'penjualan_barang.invoice = pembayaran.invoice');
		return $this->db->get()->result_array();
	}

	public function simpanBayarDetail($kodeBayar, $kd_barang)
	{
		$sql = "INSERT INTO bayar_detail (no_kwitansi,kd_barang)
				SELECT pembayaran.no_kwitansi, barang.kd_barang 
				FROM pembayaran, barang WHERE pembayaran.no_kwitansi
				='$kodeBayar' AND barang.kd_barang='$kd_barang'";
		$this->db->query($sql);
	}

	public function kodeBayar()
	{
		$this->db->select('RIGHT(pembayaran.no_kwitansi,3) as kode', FALSE);
		$this->db->order_by('no_kwitansi', 'DESC');
		$this->db->limit(1);
		$query = $this->db->get('pembayaran'); //cek apakah sudah ada kode didalam tabel
		if ($query->num_rows() <> 0) {
			//cek kode jika telah tersedia
			$data = $query->row();
			$kode = intval($data->kode) + 1;
		} else {
			$kode = 1; //cek jika kode belum terdapat pada tabel;
		}
		$char = "INV";
		$tgl = date('dmY');
		$kodemax = str_pad($kode, 3, "0", STR_PAD_LEFT);
		$kodetampil = $char . $tgl . $kodemax;

		return $kodetampil;
	}
}
