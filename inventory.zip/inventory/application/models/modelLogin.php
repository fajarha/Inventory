<?php
defined('BASEPATH') or exit('No direct script access allowed');

class modelLogin extends CI_Model
{
	// Menginput Data Regis
	public function simpanRegis($data = null)
	{
		$this->db->insert('user', $data);
	}

	// Mencari user untuk login
	public function cekLogin($data = null)
	{
		return $this->db->get_where('user', $data);
	}
	
	//	Menampilkan data user
	public function tampilData($data = null)
	{
		return $this->db->get_where('user', $data);
	}
}
