<?php
defined('BASEPATH') or exit('No direct script access allowed');

class modelAsset extends CI_Model
{
	public function tampilBrg()
	{
		$data  = $this->db->get_where('barang', 'status_barang = "Inventory"');
		return $data->result_array();
	}

	public function tampilBrgSold()
	{
		$data  = $this->db->get_where('barang', 'status_barang = "Sold"');
		return $data->result_array();
	}

	public function tampilPenjualan()
	{
		$data  = $this->db->get_where('penjualan_barang', 'status <> "Lunas"');
		return $data->result_array();
	}

	public function tambahBrg($data = null)
	{
		$this->db->insert('barang', $data);
	}

	public function editBrg($kd_barang, $data)
	{
		$this->db->where('kd_barang', $kd_barang);
		$this->db->update('barang', $data);
	}

	public function deleteBrg($id)
	{
		$this->db->where('id', $id);
		$this->db->delete('brg');
	}

	public function simpanApproval($data = null)
	{
		$this->db->insert('approval', $data);
	}

	public function tampilApproval()
	{
		$data  = $this->db->get('approval');
		return $data->result_array();
	}

	public function deleteApproval($id)
	{
		$this->db->where('id_approval', $id);
		$this->db->delete('approval');
	}

	public function simpanPending($data = null)
	{
		$this->db->insert('pending', $data);
	}

	public function tampilPending()
	{
		$data  = $this->db->get('pending');
		return $data->result_array();
	}

	public function deletePending($id)
	{
		$this->db->where('id_pending', $id);
		$this->db->delete('pending');
	}

	public function tampilJoinBarang()
	{
		$this->db->select('*');
		$this->db->from('approval');
		$this->db->join('barang', 'barang.kd_barang = approval.kd_barang');
		return $this->db->get()->result_array();
	}

	public function simpanPenjualan($data = null)
	{
		$this->db->insert('penjualan_barang', $data);
	}

	public function simpanPenjualanDetail($invoice, $kode_barang)
	{
		$sql = "INSERT INTO barang_terjual (invoice,kd_barang)
				SELECT penjualan_barang.invoice, barang.kd_barang 
				FROM penjualan_barang, barang WHERE penjualan_barang.invoice
				='$invoice' AND barang.kd_barang='$kode_barang'";
		$this->db->query($sql);
	}


	public function kodeBrg()
	{
		$this->db->select('RIGHT(barang.kd_barang,3) as kode', FALSE);
		$this->db->order_by('kd_barang', 'DESC');
		$this->db->limit(1);
		$query = $this->db->get('barang'); //cek apakah sudah ada kode didalam tabel
		if ($query->num_rows() <> 0) {
			//cek kode jika telah tersedia
			$data = $query->row();
			$kode = intval($data->kode) + 1;
		} else {
			$kode = 1; //cek jika kode belum terdapat pada tabel;
		}
		$char = "BRG";
		$tgl = date('dmY');
		$kodemax = str_pad($kode, 3, "0", STR_PAD_LEFT);
		$kodetampil = $char . $tgl . $kodemax;

		return $kodetampil;
	}

	public function kodePj()
	{
		$this->db->select('RIGHT(penjualan_barang.invoice,3) as kode', FALSE);
		$this->db->order_by('invoice', 'DESC');
		$this->db->limit(1);
		$query = $this->db->get('penjualan_barang'); //cek apakah sudah ada kode didalam tabel
		if ($query->num_rows() <> 0) {
			//cek kode jika telah tersedia
			$data = $query->row();
			$kode = intval($data->kode) + 1;
		} else {
			$kode = 1; //cek jika kode belum terdapat pada tabel;
		}
		$char = "INV";
		$tgl = date('dmY');
		$kodemax = str_pad($kode, 3, "0", STR_PAD_LEFT);
		$kodetampil = $char . $tgl . $kodemax;

		return $kodetampil;
	}

	public function tampil_kota(){
		$this->db->select('id, kota, provinsi, COUNT(provinsi) as total');
		 $this->db->group_by('provinsi'); 
		 $this->db->order_by('total', 'desc'); 
		 $hasil = $this->db->get('tablename');
		return $hasil;
	}
}
