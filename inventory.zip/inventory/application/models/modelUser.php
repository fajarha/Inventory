<?php
defined('BASEPATH') or exit('No direct script access allowed');

class modelUser extends CI_Model
{
	// Menginput Data user
	public function tambahUser($data = null)
	{
		$this->db->insert('user', $data);
	}

	public function joinUser()
	{
		$query = "SELECT `user`.* , `role`.`role`
				FROM `user` JOIN `role` 
				ON `user`.`role_id` = `role`.`id` 
				";
		return $this->db->query($query)->result_array();
	}

	public function tampilUser()
	{
		$data  = $this->db->get('user');
		return $data->result_array();
	}

	public function tampilRole()
	{
		$data  = $this->db->get('role');
		return $data->result_array();
	}

	public function edit($nik, $data)
	{
		$this->db->where('nik', $nik);
		$this->db->update('user', $data);
	}

	public function hapus($id)
	{
		$this->db->where('nik', $id);
		$this->db->delete('user');
	}
}
