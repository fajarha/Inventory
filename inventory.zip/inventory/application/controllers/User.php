<?php
defined('BASEPATH') or exit('No direct script access allowed');

class User extends CI_Controller
{
	public function index()
	{
		$data['title'] = "Detail User";
		$data['user'] = $this->modelLogin->tampilData(['nik' => $this->session->userdata('nik')])->row_array();
		$data['pengguna'] = $this->modelUser->joinUser();
		$data['role'] = $this->modelUser->tampilRole();

		$this->load->view('template/header', $data);
		$this->load->view('template/topbar', $data);
		$this->load->view('User/index', $data);
		$this->load->view('template/sidebar', $data);
		$this->load->view('template/footer', $data);
	}

	public function Create()
	{
		$data['title'] = "User Create";
		$data['user'] = $this->modelLogin->tampilData(['nik' => $this->session->userdata('nik')])->row_array();
		$data['pengguna'] = $this->modelUser->joinUser();
		$data['role'] = $this->modelUser->tampilRole();

		$this->form_validation->set_rules('nik', 'Nik', 'required');
		$this->form_validation->set_rules('nama_lengkap', 'Nama_Lengkap', 'required|trim');
		$this->form_validation->set_rules('tanggal_lahir', 'Tanggal_lahir', 'required');
		$this->form_validation->set_rules('alamat', 'Alamat', 'required|trim');
		$this->form_validation->set_rules(
			'username',
			'Username',
			'required'
		);
		$this->form_validation->set_rules(
			'password',
			'Password',
			'required|trim|min_length[5]',
			['min_length' => 'Password terlalu pendek',]
		);
		$this->form_validation->set_rules('role_id', 'Role_id', 'required|trim');

		if ($this->form_validation->run() == false) {
			$this->load->view('template/header', $data);
			$this->load->view('template/topbar', $data);
			$this->load->view('User/Create', $data);
			$this->load->view('template/sidebar', $data);
			$this->load->view('template/footer');
		} else {
			$data = [
				'nik'			 	=> $this->input->POST('nik', true),
				'nama_lengkap' 		=> $this->input->POST('nama_lengkap', true),
				'tanggal_lahir' 	=> $this->input->POST('tanggal_lahir', true),
				'alamat' 			=> $this->input->POST('alamat', true),
				'username' 			=> $this->input->POST('username', true),
				'password' 			=> md5($this->input->POST('password')),
				'role_id' 			=> $this->input->post('role_id', true)
			];

			$this->db->insert('user', $data);
			$this->session->set_flashdata('pesan', '<div class="alert alert-success" role="alert">
			User Berhasil Ditambahkan </div>');
			redirect('User/Create');
		}
	}

	public function Edit($nik)
	{
		$data['title'] = "Edit User";
		$data['user'] = $this->modelLogin->tampilData(['nik' => $this->session->userdata('nik')])->row_array();
		$nik   = $this->uri->segment(3);
		$data['pengguna'] = $this->db->get_where('user', ['nik' => $nik])->row_array();
		$data['role'] = $this->modelUser->tampilRole();

		$this->form_validation->set_rules('nama_lengkap', 'Nama_Lengkap', 'required|trim');
		$this->form_validation->set_rules('tanggal_lahir', 'Tanggal_lahir', 'required');
		$this->form_validation->set_rules('alamat', 'Alamat', 'required|trim');
		$this->form_validation->set_rules(
			'username',
			'Username',
			'required'
		);
		$this->form_validation->set_rules(
			'password',
			'Password',
			'required|trim|min_length[5]',
			['min_length' => 'Password terlalu pendek',]
		);

		if ($this->form_validation->run() == false) {
			$this->load->view('template/header', $data);
			$this->load->view('template/topbar', $data);
			$this->load->view('User/Edit', $data);
			$this->load->view('template/sidebar', $data);
			$this->load->view('template/footer');
		} else {
			$data = [
				'nama_lengkap' 		=> $this->input->POST('nama_lengkap', true),
				'tanggal_lahir' 	=> $this->input->POST('tanggal_lahir', true),
				'alamat' 			=> $this->input->POST('alamat', true),
				'username' 			=> $this->input->POST('username', true),
				'password' 			=> md5($this->input->POST('password')),
				'role_id' 			=> $this->input->POST('role_id', true)
			];

			$this->modelUser->edit($nik, $data);
			$this->session->set_flashdata('pesan', '<div class="alert alert-success" role="alert">
			User Berhasil Di Edit </div>');
			redirect('User');
		}
	}

	public function Delete()
	{
		$id = $this->uri->segment(3);
		$this->modelUser->hapus($id);

		$this->session->set_flashdata('pesan', '<div class="alert alert-success" role="alert">
            User Berhasil dihapus !
          </div>');
		redirect('User');
	}
}
