<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Main extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->library('form_validation');
	}

	public function index()
	{
		$data['title'] = "Login";

		$this->form_validation->set_rules('username', 'Username', 'required|trim');
		$this->form_validation->set_rules('password', 'Password', 'required|trim');

		// jika dia benar maka akan dijalankan ke view
		if ($this->form_validation->run() == false) {
			$this->load->view('main', $data);
		} 
		// jika dia salah maka akan dijalankan form login
		else {
			$this->_login();
		}
	}

	private function _login()
	{

		$username = $this->input->post('username');
		$password = $this->input->post('password');

		$user     = $this->modelLogin->cekLogin(['username' => $username])->row_array();

		// jika user ada
		if ($user) {
			// jika password benar
			if (md5($password, $user['password'])) {
				// ambil sebuah session 
				$data =
					[
						'nik'      => $user['nik'],
						'username' => $user['username'],
						'role_id'  => $user['role_id']
					];
				$this->session->set_userdata($data);

				// cek role id harus kemana
				if ($user['role_id'] == 1) {
					redirect('Dashboard/Administrator');
				} else if ($user['role_id'] == 2) {
					redirect('Dashboard/Manager');
				} else if ($user['role_id'] == 3) {
					redirect('Dashboard/Inventory');
				} else {
					redirect('Dashboard/Kasir');
				}
			} else {
				$this->session->set_flashdata('pesan', '<div class="alert alert-danger" role="alert">
                    Password Salah !
                  </div>');
				redirect('Main');
			}
		} else {
			$this->session->set_flashdata('pesan', '<div class="alert alert-danger" role="alert">
            Username tidak terdaftar !
          </div>');
			redirect('Main');
		}
	}

	public function logout()
	{
		$this->session->unset_userdata('nik');
		$this->session->unset_userdata('username');
		$this->session->unset_userdata('role_id');

		$this->session->set_flashdata('pesan', '<div class="alert alert-success" role="alert">
			Selamat Anda Berhasil Logout. Silahkan Login jika ingin kembali! </div>');
		redirect('Main');
	}

	public function blocked()
	{
		$this->load->view('blocked');
	}
}
