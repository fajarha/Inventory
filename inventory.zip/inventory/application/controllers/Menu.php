<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Menu extends CI_Controller
{
	public function Index()
	{
		$data['title'] = "Menu";
		$data['user'] = $this->modelLogin->tampilData(['nik' => $this->session->userdata('nik')])->row_array();
		$data['menu'] = $this->modelMenu->tampilMenu();

		$this->load->view('template/header', $data);
		$this->load->view('template/topbar', $data);
		$this->load->view('Menu/index', $data);
		$this->load->view('template/sidebar', $data);
		$this->load->view('template/footer');
	}

	public function SubMenu()
	{
		$data['title'] = "Sub Menu";
		$data['user'] = $this->modelLogin->tampilData(['nik' => $this->session->userdata('nik')])->row_array();
		$data['submenu'] = $this->modelMenu->joinSubMenu();
		$data['menu'] = $this->modelMenu->tampilMenu();

		$this->load->view('template/header', $data);
		$this->load->view('template/topbar', $data);
		$this->load->view('Menu/SubMenu', $data);
		$this->load->view('template/sidebar', $data);
		$this->load->view('template/footer');
	}

	public function Access()
	{
		$data['title'] = "Access Sub Menu";
		$data['user'] = $this->modelLogin->tampilData(['nik' => $this->session->userdata('nik')])->row_array();
		$data['access'] = $this->modelMenu->joinAccess();
		$data['menuu'] = $this->modelMenu->tampilMenu();
		$data['role'] = $this->modelMenu->tampilRole();

		$this->load->view('template/header', $data);
		$this->load->view('template/topbar', $data);
		$this->load->view('Menu/Access', $data);
		$this->load->view('template/sidebar', $data);
		$this->load->view('template/footer');
	}

	public function RoleAccess($id)
	{
		$data['title'] = "Access Sub Menu";
		$data['user'] = $this->modelLogin->tampilData(['nik' => $this->session->userdata('nik')])->row_array();
		$data['access'] = $this->modelMenu->joinAccess();
		$data['menuu'] = $this->modelMenu->tampilMenu();


		$data['role'] = $this->db->get_where('role', ['id' => $id])->row_array();

		$this->load->view('template/header', $data);
		$this->load->view('template/topbar', $data);
		$this->load->view('Menu/RoleAccess', $data);
		$this->load->view('template/sidebar', $data);
		$this->load->view('template/footer');
	}

	public function changeAccess()
	{

		$menu_id = $this->input->post('menuId');
		$role_id = $this->input->post('roleId');

		$data = [
			'role_id' => $role_id,
			'menu_id' => $menu_id
		];

		$result = $this->db->get_where('user_access_menu', $data);

		if ($result->num_rows() < 1) {
			$this->db->insert('user_access_menu', $data);
		} else {
			$this->db->delete('user_access_menu', $data);
		}

		$this->session->set_flashdata('pesan', '<div class="alert alert-success" role="alert">
			Access Berhasil diubah </div>');
	}

	public function editRole()
	{

		$this->form_validation->set_rules('role', 'Role', 'required|trim');
		$id	= $this->input->post('id');

		$data = [
			'role' => $this->input->post('role')
		];

		$this->modelMenu->editRole($id, $data);
		$this->session->set_flashdata('pesan', '<div class="alert alert-success" role="alert">
			Role Berhasil Diedit </div>');
		redirect('Menu/Access');
	}

	public function createRole()
	{

		$this->form_validation->set_rules('role', 'Role', 'required|trim');
		$data = [
			'role' => $this->input->post('role')
		];

		$this->modelMenu->tambahRole($data);
		$this->session->set_flashdata('pesan', '<div class="alert alert-success" role="alert">
			Role Berhasil Ditambah </div>');
		redirect('Menu/Access');
	}

	public function deleteRole()
	{
		$id = $this->uri->segment(3);
		$this->modelMenu->deleteRole($id);

		$this->session->set_flashdata('pesan', '<div class="alert alert-success" role="alert">
			Role Berhasil Dihapus </div>');
		redirect('Menu/Access');
	}



	public function createMenu()
	{
		$this->form_validation->set_rules('menu', 'Menu', 'required|trim');
		$this->form_validation->set_rules('icon', 'Icon', 'required|trim');

		$data = [
			'menu' => $this->input->post('menu'),
			'icon' => $this->input->post('icon')
		];

		$this->modelMenu->tambahMenu($data);
		$this->session->set_flashdata('pesan', '<div class="alert alert-success" role="alert">
			Menu Berhasil Ditambahkan </div>');
		redirect('Menu');
	}

	public function editMenu()
	{

		$this->form_validation->set_rules('menu', 'Menu', 'required|trim');
		$this->form_validation->set_rules('icon', 'Icon', 'required|trim');
		$id	= $this->input->post('id');

		$data = [
			'menu' => $this->input->post('menu'),
			'icon' => $this->input->post('icon')
		];

		$this->modelMenu->editMenu($id, $data);
		$this->session->set_flashdata('pesan', '<div class="alert alert-success" role="alert">
			Menu Berhasil Diedit </div>');
		redirect('Menu');
	}

	public function deleteMenu()
	{
		$id = $this->uri->segment(3);
		$this->modelMenu->deleteMenu($id);

		$this->session->set_flashdata('pesan', '<div class="alert alert-success" role="alert">
			Menu Berhasil Dihapus </div>');
		redirect('Menu');
	}

	public function createSubMenu()
	{
		$this->form_validation->set_rules('menu_id', 'Menu', 'required|trim');
		$this->form_validation->set_rules('title', 'Title', 'required|trim');
		$this->form_validation->set_rules('url', 'Url', 'required|trim');
		$this->form_validation->set_rules('iconic', 'Iconic', 'required|trim');


		$data = [
			'menu_id' => $this->input->post('menu_id'),
			'title' => $this->input->post('title'),
			'url' => $this->input->post('url'),
			'iconic' => $this->input->post('iconic'),
			'is_active' => $this->input->post('is_active')
		];

		$this->modelMenu->tambahSubMenu($data);
		$this->session->set_flashdata('pesan', '<div class="alert alert-success" role="alert">
			Sub Menu Berhasil Ditambahkan </div>');
		redirect('Menu/SubMenu');
	}

	public function editSubMenu()
	{
		$this->form_validation->set_rules('menu_id', 'Menu', 'required|trim');
		$this->form_validation->set_rules('title', 'Title', 'required|trim');
		$this->form_validation->set_rules('url', 'Url', 'required|trim');
		$this->form_validation->set_rules('iconic', 'Iconic', 'required|trim');
		$id	= $this->input->post('id');

		$data = [
			'menu_id' => $this->input->post('menu_id'),
			'title' => $this->input->post('title'),
			'url' => $this->input->post('url'),
			'iconic' => $this->input->post('iconic'),
			'is_active' => $this->input->post('is_active')
		];

		$this->modelMenu->editSubMenu($id, $data);
		$this->session->set_flashdata('pesan', '<div class="alert alert-success" role="alert">
			Sub Menu Berhasil Diedit </div>');
		redirect('Menu/SubMenu');
	}

	public function deleteSubMenu()
	{
		$id = $this->uri->segment(3);
		$this->modelMenu->deleteSubMenu($id);

		$this->session->set_flashdata('pesan', '<div class="alert alert-success" role="alert">
			Sub Menu Berhasil Dihapus </div>');
		redirect('Menu/SubMenu');
	}
}
