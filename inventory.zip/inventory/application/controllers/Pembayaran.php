<?php
defined('BASEPATH') or exit('No direct script access allowed');
date_default_timezone_set('Asia/Jakarta');

class Pembayaran extends CI_Controller
{
	public function Input()
	{
		$data['title'] = "Input Pembayaran";
		$data['user'] = $this->modelLogin->tampilData(['nik' => $this->session->userdata('nik')])->row_array();
		$data['terjual'] = $this->modelAsset->tampilPenjualan();

		$this->load->view('template/header', $data);
		$this->load->view('template/topbar', $data);
		$this->load->view('Pembayaran/Input', $data);
		$this->load->view('template/sidebar', $data);
		$this->load->view('template/footer');
	}

	public function Bayar()
	{
		$data['title'] = "Input Pembayaran";
		$data['user'] = $this->modelLogin->tampilData(['nik' => $this->session->userdata('nik')])->row_array();
		$data['terjual'] = $this->modelAsset->tampilPenjualan();

		$this->form_validation->set_rules('kd_barang', 'kd_barang', 'required|trim');
		$this->form_validation->set_rules('invoice', 'invoice', 'required|trim');
		$this->form_validation->set_rules('jumlah_pembayaran', 'jumlah_pembayaran', 'required|trim');
		$kodeBayar 		= $this->modelBayar->kodeBayar('pembayaran', 'no_kwitansi');
		$tglsekarang	= date('Y-m-d');
		$kd_barang = $this->input->post('kd_barang');

		$data = [
			'no_kwitansi' 		 => $kodeBayar,
			'kd_barang'	  		 => $this->input->post('kd_barang'),
			'invoice'	  		 => $this->input->post('invoice'),
			'jumlah_pembayaran'  => $this->input->post('jumlah_pembayaran'),
			'tanggal_pembayaran' => $tglsekarang
		];

		$this->modelBayar->simpanBayar($data);

		$this->modelBayar->simpanBayarDetail($kodeBayar, $kd_barang);

		$this->db->query("UPDATE barang, bayar_detail SET barang.status_barang = 'Release' WHERE 
						 barang.kd_barang=bayar_detail.kd_barang");

		$this->db->query("UPDATE barang, bayar_detail SET barang.ovd = '-' WHERE 
						 barang.kd_barang=bayar_detail.kd_barang");

		$this->db->query("UPDATE penjualan_barang, pembayaran SET penjualan_barang.status = 'Lunas' WHERE 
			penjualan_barang.invoice=pembayaran.invoice");

		$data['title'] = "Kwitansi";
		$bayar  = $this->db->query("SELECT*FROM pembayaran WHERE kd_barang = '$kd_barang'")->result();
		foreach ($bayar as $d) {
			$data['no_kwitansi'] 		= $d->no_kwitansi;
			$data['kd_barang'] 			= $d->kd_barang;
			$data['invoice']		 	= $d->invoice;
			$data['jumlah_pembayaran'] 	= $d->jumlah_pembayaran;
			$data['tanggal_pembayaran'] = $d->tanggal_pembayaran;
		}

		$namaPembeli  = $this->db->query("SELECT*FROM penjualan_barang WHERE kd_barang = '$kd_barang'")->result();
		foreach ($namaPembeli as $n) {
			$data['nama_pembeli'] = $n->nama_pembeli;
			$data['harga_pembelian'] = $n->harga_pembelian;
		}

		$this->load->view('Pembayaran/cetakBayar', $data);
	}
}
