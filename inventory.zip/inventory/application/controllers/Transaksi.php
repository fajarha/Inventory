<?php
defined('BASEPATH') or exit('No direct script access allowed');
date_default_timezone_set('Asia/Jakarta');

class Transaksi extends CI_Controller
{
	public function Penjualan()
	{
		$data['title'] = "Penjualan Asset";
		$data['user'] = $this->modelLogin->tampilData(['nik' => $this->session->userdata('nik')])->row_array();
		$tgl = date('Y-m-d');
		$this->form_validation->set_rules('nik_pembeli', 'Nik_pembeli', 'trim|min_length[16]', ['min_length' => 'NIK Harus 16 Angka']);
		$this->form_validation->set_rules('nama_pembeli', 'Nama_Pembeli', 'required|trim');
		$this->form_validation->set_rules('kode_barang', 'kode_barang', 'required|trim');
		$this->form_validation->set_rules('harga_pembelian', 'Harga_pembelian', 'required|trim');

		$this->form_validation->set_message('required', 'Silahkan diisi !');
		$this->form_validation->set_error_delimiters('<span class="help-block">', '</span>');

		if ($this->form_validation->run() == false) {
			$this->load->view('template/header', $data);
			$this->load->view('template/topbar', $data);
			$this->load->view('Transaksi/Penjualan', $data);
			$this->load->view('template/sidebar', $data);
			$this->load->view('template/footer');
		} else {
			$data = [
				'nik_pembeli'		 => $this->input->post('nik_pembeli'),
				'nama_pembeli' 		 => $this->input->post('nama_pembeli'),
				'harga_pembelian' 	 => $this->input->post('harga_pembelian'),
				'kd_barang'			 => $this->input->post('kode_barang'),
				'tanggal_pembelian'  => $tgl
			];

			$this->modelAsset->simpanApproval($data);
			$this->session->set_flashdata('pesan', '<div class="alert alert-success" role="alert">
			Penjualan Berhasil Disimpan, Silahkan tunggu Approval Manager </div>');
			redirect('Transaksi/Penjualan');
		}
	}

	public function PenjualanAct()
	{
		$data['title'] = "Penjualan Asset";
		$id = $this->input->post('id_pending');

		$this->form_validation->set_rules('nik_pembeli', 'Nik_pembeli', 'trim|min_length[16]', ['min_length' => 'NIK Harus 16 Angka']);
		$this->form_validation->set_rules('nama_pembeli', 'Nama_Pembeli', 'required|trim');
		$this->form_validation->set_rules('kode_barang', 'kode_barang', 'required|trim');
		$this->form_validation->set_rules('harga_pembelian', 'Harga_pembelian', 'required|trim');

		$this->form_validation->set_message('required', 'Silahkan diisi !');
		$this->form_validation->set_error_delimiters('<span class="help-block">', '</span>');


		$data = [
			'nik_pembeli'		 => $this->input->post('nik_pembeli'),
			'nama_pembeli' 		 => $this->input->post('nama_pembeli'),
			'harga_pembelian' 	 => $this->input->post('harga_pembelian'),
			'kd_barang'			 => $this->input->post('kode_barang'),
			'tanggal_pembelian'  => $this->input->post('tanggal_pembelian')
		];

		$this->modelAsset->simpanApproval($data);
		$this->modelAsset->deletePending($id);
		$this->session->set_flashdata('pesan', '<div class="alert alert-success" role="alert">
			Penjualan Berhasil Disimpan, Silahkan tunggu Approval Manager </div>');
		redirect('Asset/Pending');
	}

	public function Approval()
	{
		$data['title']    = "Approval Penjualan";
		$data['user']     = $this->modelLogin->tampilData(['nik' => $this->session->userdata('nik')])->row_array();
		$data['approval'] = $this->modelAsset->tampilApproval();

		$this->load->view('template/header', $data);
		$this->load->view('template/topbar', $data);
		$this->load->view('Transaksi/Approval', $data);
		$this->load->view('template/sidebar', $data);
		$this->load->view('template/footer');
	}

	public function PendingAct()
	{
		$data['user'] = $this->modelLogin->tampilData(['nik' => $this->session->userdata('nik')])->row_array();
		$id = $this->input->post('id_approval');

		$this->form_validation->set_rules('nik_pembeli', 'Nik_pembeli', 'trim|min_length[16]', ['min_length' => 'NIK Harus 16 Angka']);
		$this->form_validation->set_rules('nama_pembeli', 'Nama_Pembeli', 'required|trim');
		$this->form_validation->set_rules('kode_barang', 'kode_barang', 'required|trim');
		$this->form_validation->set_rules('harga_pembelian', 'Harga_pembelian', 'required|trim');
		$this->form_validation->set_rules('keterangan', 'Keterangan', 'required|trim');
		$this->form_validation->set_rules('tanggal_pembelian', 'Tanggal_pembelian', 'required|trim');

		$this->form_validation->set_message('required', 'Silahkan diisi !');
		$this->form_validation->set_error_delimiters('<span class="help-block">', '</span>');

		$data = [
			'nik_pembeli'		 => $this->input->post('nik_pembeli'),
			'nama_pembeli' 		 => $this->input->post('nama_pembeli'),
			'harga_pembelian' 	 => $this->input->post('harga_pembelian'),
			'kd_barang'			 => $this->input->post('kode_barang'),
			'tanggal_pembelian'  => $this->input->post('tanggal_pembelian'),
			'keterangan'		 => $this->input->post('keterangan')
		];

		$this->modelAsset->simpanPending($data);
		$this->modelAsset->deleteApproval($id);
		$this->session->set_flashdata('pesan', '<div class="alert alert-success" role="alert">
			Penjualan Telah Terpending </div>');
		redirect('Transaksi/Approval');
	}

	public function ApproveAct()
	{
		$id_approval = $this->uri->segment(3);
		$invoice = $this->modelAsset->kodePj();
		$approval = $this->db->query("SELECT*FROM approval where id_approval = '$id_approval'")->row_array();
		$kode_barang = $approval['kd_barang'];

		$data = [
			'invoice'			=> $invoice,
			'nama_pembeli'		=> $approval['nama_pembeli'],
			'nik_pembeli'		=> $approval['nik_pembeli'],
			'kd_barang'			=> $approval['kd_barang'],
			'harga_pembelian'	=> $approval['harga_pembelian'],
			'tanggal_pembelian' => $approval['tanggal_pembelian'],
			'status'			=> 'Waiting'
		];

		$this->modelAsset->simpanPenjualan($data);
		$this->modelAsset->simpanPenjualanDetail($invoice, $kode_barang);


		$this->db->query("UPDATE barang, barang_terjual SET barang.status_barang = 'Sold' WHERE 
						 barang.kd_barang=barang_terjual.kd_barang");

		$this->modelAsset->deleteApproval($id_approval);
		$this->session->set_flashdata('pesan', '<div class="alert alert-success" role="alert">
		Penjualan Berhasil Dilakukan </div>');
		redirect('Transaksi/Approval');
	}
}
