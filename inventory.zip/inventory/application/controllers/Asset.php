<?php
defined('BASEPATH') or exit('No direct script access allowed');
date_default_timezone_set('Asia/Jakarta');

class Asset extends CI_Controller
{
	public function Stok()
	{
		$data['title'] = "Stok Asset";
		$data['user'] = $this->modelLogin->tampilData(['nik' => $this->session->userdata('nik')])->row_array();
		$data['barang']  = $this->modelAsset->tampilBrg();

		$this->load->view('template/header', $data);
		$this->load->view('template/topbar', $data);
		$this->load->view('Asset/Stok', $data);
		$this->load->view('template/sidebar', $data);
		$this->load->view('template/footer');
	}

	public function detailAsset()
	{
		$data['title'] = "Detail Asset";
		$data['user'] = $this->modelLogin->tampilData(['nik' => $this->session->userdata('nik')])->row_array();
		$kd_brg = $this->uri->segment(3);
		$detail  = $this->db->query("SELECT*FROM barang WHERE kd_barang = '$kd_brg'")->result();
		foreach ($detail as $d) {
			$data['kd_barang'] = $d->kd_barang;
			$data['nik'] = $d->nik;
			$data['nama_customer'] = $d->nama_customer;
			$data['no_aggrement'] = $d->no_aggrement;
			$data['status_konsumen'] = $d->status_konsumen;
			$data['ovd'] = $d->ovd;
			$data['merk'] = $d->merk;
			$data['kategori'] = $d->kategori;
			$data['no_rangka'] = $d->no_rangka;
			$data['no_serial'] = $d->no_serial;
			$data['no_mesin'] = $d->no_mesin;
			$data['no_polisi'] = $d->no_polisi;
			$data['warna'] = $d->warna;
			$data['status_barang'] = $d->status_barang;
			$data['otr'] = $d->otr;
			$data['nilai_barang'] = $d->nilai_barang;
			$data['sisa_denda'] = $d->sisa_denda;
			$data['nilai_denda'] = $d->nilai_denda;
			$data['biaya_tarik'] = $d->biaya_tarik;
			$data['umur_barang'] = $d->umur_barang;
			$data['nik_collector'] = $d->nik_collector;
			$data['nama_collector'] = $d->nama_collector;
			$data['lokasi'] = $d->lokasi;
			$data['tanggal_stnk'] = $d->tanggal_stnk;
			$data['tanggal_pajak'] = $d->tanggal_pajak;
			$data['deskripsi_barang'] = $d->deskripsi_barang;
		}

		$this->load->view('template/header', $data);
		$this->load->view('template/topbar', $data);
		$this->load->view('Asset/DetailAsset', $data);
		$this->load->view('template/sidebar', $data);
		$this->load->view('template/footer');
	}

	public function Receive()
	{
		$data['title'] = "Asset Receive";
		$data['user'] = $this->modelLogin->tampilData(['nik' => $this->session->userdata('nik')])->row_array();

		$kodeBrg 		= $this->modelAsset->kodeBrg('barang', 'kd_barang');
		$tglsekarang	= date('Y-m-d');
		$this->form_validation->set_rules('nik', 'Nik', 'trim|min_length[16]', ['min_lentgh' => 'NIK Harus 16 Angka']);
		$this->form_validation->set_rules('nama_customer', 'Nama_customer', 'required|trim');
		$this->form_validation->set_rules('no_aggrement', 'no_aggrement', 'required|trim|min_length[14]', ['min_length' => 'No Aggrement Harus 14 Angka']);
		$this->form_validation->set_rules('ovd', 'Ovd', 'required|trim');
		$this->form_validation->set_rules('status_konsumen', 'Status_konsumen', 'required|trim');
		$this->form_validation->set_rules('kategori', 'Kategori', 'required|trim');
		$this->form_validation->set_rules('merk', 'merk', 'required|trim');
		$this->form_validation->set_rules('no_rangka', 'No_rangka', 'trim');
		$this->form_validation->set_rules('no_serial', 'No_serial', 'trim');
		$this->form_validation->set_rules('no_mesin', 'No_mesin', 'trim');
		$this->form_validation->set_rules('no_polisi', 'No_polisi', 'trim');
		$this->form_validation->set_rules('status_barang', 'Status_barang', 'required|trim');
		$this->form_validation->set_rules('otr', 'Otr', 'required|trim');
		$this->form_validation->set_rules('nilai_barang', 'Nilai_barang', 'required|trim');
		$this->form_validation->set_rules('nilai_denda', 'Nilai_denda', 'required|trim');
		$this->form_validation->set_rules('sisa_denda', 'Sisa_denda', 'required|trim');
		$this->form_validation->set_rules('biaya_tarik', 'Biaya_tarik', 'required|trim');
		$this->form_validation->set_rules('nik_collector', 'Nik_collector', 'required|trim');
		$this->form_validation->set_rules('nama_collector', 'Nama_collector', 'required|trim');
		$this->form_validation->set_rules('lokasi', 'Lokasi', 'required|trim');
		$this->form_validation->set_rules('tanggal_stnk', 'Tanggal_stnk', 'trim');
		$this->form_validation->set_rules('tanggal_pajak', 'Tanggal_pajak', 'trim');
		$this->form_validation->set_rules('deskripsi_barang', 'deskripsi_barang', 'required|trim');

		$this->form_validation->set_message('required', 'Silahkan diisi !');
		$this->form_validation->set_error_delimiters('<span class="help-block">', '</span>');

		if ($this->form_validation->run() == false) {
			$this->load->view('template/header', $data);
			$this->load->view('template/topbar', $data);
			$this->load->view('Asset/Receive', $data);
			$this->load->view('template/sidebar', $data);
			$this->load->view('template/footer');
		} else {
			$data = [
				'kd_barang'			 => $kodeBrg,
				'nik'				 => $this->input->post('nik'),
				'nama_customer'		 => $this->input->post('nama_customer'),
				'no_aggrement' 	   	 => $this->input->post('no_aggrement'),
				'ovd' 				 => $this->input->post('ovd'),
				'status_konsumen' 	 => $this->input->post('status_konsumen'),
				'kategori' 			 => $this->input->post('kategori'),
				'merk' 				 => $this->input->post('merk'),
				'no_rangka' 		 => $this->input->post('no_rangka'),
				'no_serial' 		 => $this->input->post('no_serial'),
				'no_mesin' 			 => $this->input->post('no_mesin'),
				'warna' 			 => $this->input->post('warna'),
				'no_polisi' 		 => $this->input->post('no_polisi'),
				'status_barang' 	 => $this->input->post('status_barang'),
				'otr' 			 	 => $this->input->post('otr'),
				'nilai_barang' 		 => $this->input->post('nilai_barang'),
				'nilai_denda' 		 => $this->input->post('nilai_denda'),
				'sisa_denda' 		 => $this->input->post('sisa_denda'),
				'biaya_tarik' 		 => $this->input->post('biaya_tarik'),
				'umur_barang' 		 => $tglsekarang,
				'nik_collector' 	 => $this->input->post('nik_collector'),
				'nama_collector' 	 => $this->input->post('nama_collector'),
				'lokasi' 			 => $this->input->post('lokasi'),
				'tanggal_stnk' 		 => $this->input->post('tanggal_stnk'),
				'tanggal_pajak' 	 => $this->input->post('tanggal_pajak'),
				'deskripsi_barang'   => $this->input->post('deskripsi_barang')
			];

			$this->modelAsset->tambahBrg($data);
			$this->session->set_flashdata('pesan', '<div class="alert alert-success" role="alert">
			Asset Berhasil Ditambahkan </div>');
			redirect('Asset/Receive');
		}
	}

	public function editBrg()
	{
		$data['title'] = "Asset Edit";
		$data['user'] = $this->modelLogin->tampilData(['nik' => $this->session->userdata('nik')])->row_array();
		$kd_brg = $this->uri->segment(3);
		$data['edit']  = $this->db->query("SELECT*FROM barang WHERE kd_barang = '$kd_brg'")->row_array();

		$this->form_validation->set_rules('nik', 'Nik', 'trim|min_length[16]', ['min_lentgh' => 'NIK Harus 16 Angka']);
		$this->form_validation->set_rules('nama_customer', 'Nama_customer', 'required|trim');
		$this->form_validation->set_rules('no_aggrement', 'no_aggrement', 'required|trim|min_length[14]', ['min_length' => 'No Aggrement Harus 14 Angka']);
		$this->form_validation->set_rules('ovd', 'Ovd', 'required|trim');
		$this->form_validation->set_rules('status_konsumen', 'Status_konsumen', 'required|trim');
		$this->form_validation->set_rules('kategori', 'Kategori', 'required|trim');
		$this->form_validation->set_rules('merk', 'merk', 'required|trim');
		$this->form_validation->set_rules('no_rangka', 'No_rangka', 'trim');
		$this->form_validation->set_rules('no_serial', 'No_serial', 'trim');
		$this->form_validation->set_rules('no_mesin', 'No_mesin', 'trim');
		$this->form_validation->set_rules('no_polisi', 'No_polisi', 'trim');
		$this->form_validation->set_rules('status_barang', 'Status_barang', 'required|trim');
		$this->form_validation->set_rules('otr', 'Otr', 'required|trim');
		$this->form_validation->set_rules('nilai_barang', 'Nilai_barang', 'required|trim');
		$this->form_validation->set_rules('nilai_denda', 'Nilai_denda', 'required|trim');
		$this->form_validation->set_rules('sisa_denda', 'Sisa_denda', 'required|trim');
		$this->form_validation->set_rules('biaya_tarik', 'Biaya_tarik', 'required|trim');
		$this->form_validation->set_rules('nik_collector', 'Nik_collector', 'required|trim');
		$this->form_validation->set_rules('nama_collector', 'Nama_collector', 'required|trim');
		$this->form_validation->set_rules('lokasi', 'Lokasi', 'required|trim');
		$this->form_validation->set_rules('tanggal_stnk', 'Tanggal_stnk', 'trim');
		$this->form_validation->set_rules('tanggal_pajak', 'Tanggal_pajak', 'trim');
		$this->form_validation->set_rules('deskripsi_barang', 'deskripsi_barang', 'required|trim');

		$this->form_validation->set_message('required', 'Silahkan diisi !');
		$this->form_validation->set_error_delimiters('<span class="help-block">', '</span>');
		$kd_barang		    = $this->input->post('kd_barang');

		if ($this->form_validation->run() == false) {
			$this->load->view('template/header', $data);
			$this->load->view('template/topbar', $data);
			$this->load->view('Asset/Edit', $data);
			$this->load->view('template/sidebar', $data);
			$this->load->view('template/footer');
		} else {
			$data = [
				'nik'			   	=> $this->input->post('nik'),
				'nama_customer'		=> $this->input->post('nama_customer'),
				'no_aggrement'    	=> $this->input->post('no_aggrement'),
				'ovd' 				=> $this->input->post('ovd'),
				'status_konsumen' 	=> $this->input->post('status_konsumen'),
				'kategori' 			=> $this->input->post('kategori'),
				'umur_barang' 		=> $this->input->post('umur_barang'),
				'merk' 				=> $this->input->post('merk'),
				'no_rangka' 		=> $this->input->post('no_rangka'),
				'no_serial' 		=> $this->input->post('no_serial'),
				'no_mesin' 			=> $this->input->post('no_mesin'),
				'warna' 			=> $this->input->post('warna'),
				'no_polisi'			=> $this->input->post('no_polisi'),
				'status_barang' 	=> $this->input->post('status_barang'),
				'otr' 			 	=> $this->input->post('otr'),
				'nilai_barang' 		=> $this->input->post('nilai_barang'),
				'nilai_denda' 		=> $this->input->post('nilai_denda'),
				'sisa_denda' 		=> $this->input->post('sisa_denda'),
				'biaya_tarik' 		=> $this->input->post('biaya_tarik'),
				'nik_collector'		=> $this->input->post('nik_collector'),
				'nama_collector' 	=> $this->input->post('nama_collector'),
				'lokasi' 			=> $this->input->post('lokasi'),
				'tanggal_stnk' 		=> $this->input->post('tanggal_stnk'),
				'tanggal_pajak' 	=> $this->input->post('tanggal_pajak'),
				'deskripsi_barang' 	=> $this->input->post('deskripsi_barang')
			];

			$this->modelAsset->editBrg($kd_barang, $data);
			$this->session->set_flashdata('pesan', '<div class="alert alert-success" role="alert">
			Asset Berhasil Diedit </div>');
			redirect('Asset/Detail');
		}
	}

	public function stikerBrg()
	{
		$data['title'] = "Stiker Barang";
		$data['user'] = $this->modelLogin->tampilData(['nik' => $this->session->userdata('nik')])->row_array();
		$kd_brg = $this->uri->segment(3);
		$detail  = $this->db->query("SELECT*FROM barang WHERE kd_barang = '$kd_brg'")->result();
		foreach ($detail as $d) {
			$data['kd_barang'] = $d->kd_barang;
			$data['nik'] = $d->nik;
			$data['nama_customer'] = $d->nama_customer;
			$data['no_aggrement'] = $d->no_aggrement;
			$data['status_konsumen'] = $d->status_konsumen;
			$data['ovd'] = $d->ovd;
			$data['merk'] = $d->merk;
			$data['kategori'] = $d->kategori;
			$data['no_rangka'] = $d->no_rangka;
			$data['no_serial'] = $d->no_serial;
			$data['no_mesin'] = $d->no_mesin;
			$data['no_polisi'] = $d->no_polisi;
			$data['warna'] = $d->warna;
			$data['status_barang'] = $d->status_barang;
			$data['otr'] = $d->otr;
			$data['nilai_barang'] = $d->nilai_barang;
			$data['sisa_denda'] = $d->sisa_denda;
			$data['nilai_denda'] = $d->nilai_denda;
			$data['biaya_tarik'] = $d->biaya_tarik;
			$data['umur_barang'] = $d->umur_barang;
			$data['nik_collector'] = $d->nik_collector;
			$data['nama_collector'] = $d->nama_collector;
			$data['lokasi'] = $d->lokasi;
			$data['tanggal_stnk'] = $d->tanggal_stnk;
			$data['tanggal_pajak'] = $d->tanggal_pajak;
			$data['deskripsi_barang'] = $d->deskripsi_barang;
		}

		$this->load->view('Asset/StikerBrg', $data);
		$this->load->library('dompdf_gen');


		$paper_size = 'A4';
		$orientation = 'potrait';
		$html = $this->output->get_output();

		$this->dompdf->set_paper($paper_size, $orientation);
		$this->dompdf->load_html($html);
		$this->dompdf->render();
		$this->dompdf->stream("stiker.pdf", array('Attachment' => false));
	}

	public function Pending()
	{
		$data['title']    = "Penjualan Terpending";
		$data['user']     = $this->modelLogin->tampilData(['nik' => $this->session->userdata('nik')])->row_array();
		$data['pending'] = $this->modelAsset->tampilPending();

		$this->load->view('template/header', $data);
		$this->load->view('template/topbar', $data);
		$this->load->view('Asset/Pending', $data);
		$this->load->view('template/sidebar', $data);
		$this->load->view('template/footer');
	}

	public function Terjual()
	{
		$data['title']    = "Asset Terjual";
		$data['user']     = $this->modelLogin->tampilData(['nik' => $this->session->userdata('nik')])->row_array();
		$data['terjual'] = $this->modelAsset->tampilBrgSold();

		$this->load->view('template/header', $data);
		$this->load->view('template/topbar', $data);
		$this->load->view('Asset/Terjual', $data);
		$this->load->view('template/sidebar', $data);
		$this->load->view('template/footer');
	}
}
