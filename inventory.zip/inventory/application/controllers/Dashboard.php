<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Dashboard extends CI_Controller
{
	public function Administrator()
	{
		$data['title'] = "Dashboard";
		$data['user'] = $this->modelLogin->tampilData(['nik' => $this->session->userdata('nik')])->row_array();
		$data['pengguna'] = $this->modelUser->joinUser();
		$data['role'] = $this->modelUser->tampilRole();

		$this->load->view('template/header', $data);
		$this->load->view('template/topbar', $data);
		$this->load->view('dashboard/Administrator', $data);
		$this->load->view('template/sidebar', $data);
		$this->load->view('template/footer');
	}

	public function Manager()
	{
		$data['title'] = "Dashboard";
		$data['user'] = $this->modelLogin->tampilData(['nik' => $this->session->userdata('nik')])->row_array();
		$data['pengguna'] = $this->modelUser->joinUser();
		$data['role'] = $this->modelUser->tampilRole();

		$this->load->view('template/header', $data);
		$this->load->view('template/topbar', $data);
		$this->load->view('dashboard/Manager', $data);
		$this->load->view('template/sidebar', $data);
		$this->load->view('template/footer');
	}

	public function Inventory()
	{
		$data['title'] = "Dashboard";
		$data['user'] = $this->modelLogin->tampilData(['nik' => $this->session->userdata('nik')])->row_array();
		$data['pengguna'] = $this->modelUser->joinUser();
		$data['role'] = $this->modelUser->tampilRole();

		$this->load->view('template/header', $data);
		$this->load->view('template/topbar', $data);
		$this->load->view('dashboard/Inventory', $data);
		$this->load->view('template/sidebar', $data);
		$this->load->view('template/footer');
	}

	public function Kasir()
	{
		$data['title'] = "Dashboard";
		$data['user'] = $this->modelLogin->tampilData(['nik' => $this->session->userdata('nik')])->row_array();
		$data['pengguna'] = $this->modelUser->joinUser();
		$data['role'] = $this->modelUser->tampilRole();

		$this->load->view('template/header', $data);
		$this->load->view('template/topbar', $data);
		$this->load->view('dashboard/Kasir', $data);
		$this->load->view('template/sidebar', $data);
		$this->load->view('template/footer');
	}
}
